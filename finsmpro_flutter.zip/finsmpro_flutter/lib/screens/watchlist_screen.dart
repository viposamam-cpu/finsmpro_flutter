import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/watch_item.dart';
import '../providers/watchlist_providers.dart';
import 'analysis_screen.dart';

class WatchlistScreen extends ConsumerWidget {
  const WatchlistScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(watchlistProvider);
    final filtered = ref.watch(filteredWatchlistProvider);
    final filter = ref.watch(watchFilterProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('قائمة المراقبة'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.read(watchlistProvider.notifier).refresh(),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ابحث برمز السهم أو الاسم...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (v) => ref.read(watchQueryProvider.notifier).state = v,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                _FilterChip(
                  label: 'الكل',
                  selected: filter == WatchFilter.all,
                  onTap: () => ref.read(watchFilterProvider.notifier).state = WatchFilter.all,
                ),
                const SizedBox(width: 8),
                _FilterChip(
                  label: 'فرص شراء',
                  color: Colors.green,
                  selected: filter == WatchFilter.buy,
                  onTap: () => ref.read(watchFilterProvider.notifier).state = WatchFilter.buy,
                ),
                const SizedBox(width: 8),
                _FilterChip(
                  label: 'إشارات بيع',
                  color: Colors.red,
                  selected: filter == WatchFilter.sell,
                  onTap: () => ref.read(watchFilterProvider.notifier).state = WatchFilter.sell,
                ),
                const Spacer(),
                if (state.loading)
                  const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: filtered.isEmpty
                ? const Center(child: Text('لا توجد نتائج'))
                : RefreshIndicator(
                    onRefresh: () => ref.read(watchlistProvider.notifier).refresh(),
                    child: ListView.separated(
                      itemCount: filtered.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) => _WatchTile(item: filtered[i]),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.color,
  });
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
      selectedColor: c.withOpacity(0.18),
      labelStyle: TextStyle(color: selected ? c : null, fontWeight: FontWeight.w600),
    );
  }
}

class _WatchTile extends StatelessWidget {
  const _WatchTile({required this.item});
  final WatchItem item;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => AnalysisScreen(sym: item.sym, name: item.name),
      )),
      title: Text('${item.name} (${item.sym})',
          style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: item.sl != null && item.tp != null
          ? Text('وقف: ${item.sl!.toStringAsFixed(2)}  •  هدف: ${item.tp!.toStringAsFixed(2)}')
          : null,
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(item.price != null ? item.price!.toStringAsFixed(2) : '---',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          Container(
            margin: const EdgeInsets.only(top: 4),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: _hex(item.color).withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(item.signal,
                style: TextStyle(color: _hex(item.color), fontSize: 12, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Color _hex(String hex) {
    var h = hex.replaceAll('#', '');
    if (h.length == 6) h = 'FF$h';
    return Color(int.parse(h, radix: 16));
  }
}
