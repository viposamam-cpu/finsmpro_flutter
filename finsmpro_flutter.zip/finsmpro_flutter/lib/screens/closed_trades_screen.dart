import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/closed_trade.dart';
import '../providers/closed_trades_providers.dart';

class ClosedTradesScreen extends ConsumerWidget {
  const ClosedTradesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final trades = ref.watch(closedTradesProvider);
    final (totalNet, wins, losses) = ref.watch(closedTradesSummaryProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('سجل الصفقات المغلقة'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.read(closedTradesProvider.notifier).refresh(),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _stat('الصافي الكلي', totalNet.toStringAsFixed(0),
                        color: totalNet >= 0 ? Colors.green : Colors.red),
                    _stat('صفقات رابحة', '$wins', color: Colors.green),
                    _stat('صفقات خاسرة', '$losses', color: Colors.red),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: trades.isEmpty
                ? const Center(child: Text('لا توجد صفقات مغلقة بعد'))
                : RefreshIndicator(
                    onRefresh: () => ref.read(closedTradesProvider.notifier).refresh(),
                    child: ListView.separated(
                      itemCount: trades.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) => _TradeTile(t: trades[i]),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, {required Color color}) => Column(
        children: [
          Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: color)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
        ],
      );
}

class _TradeTile extends StatelessWidget {
  const _TradeTile({required this.t});
  final ClosedTrade t;

  @override
  Widget build(BuildContext context) {
    final color = t.isWin ? Colors.green : Colors.red;
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color.withOpacity(0.15),
        child: Icon(t.isWin ? Icons.trending_up : Icons.trending_down, color: color, size: 18),
      ),
      title: Text('${t.name} (${t.sym})', style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${t.shares} سهم  •  ${t.buyPrice.toStringAsFixed(2)} → '
          '${t.sellPrice.toStringAsFixed(2)}  •  ${t.ts}'),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text('${t.netPnl >= 0 ? '+' : ''}${t.netPnl.toStringAsFixed(1)}',
              style: TextStyle(fontWeight: FontWeight.bold, color: color)),
          Text('${t.pnlPct >= 0 ? '+' : ''}${t.pnlPct.toStringAsFixed(1)}%',
              style: TextStyle(fontSize: 11, color: color)),
        ],
      ),
    );
  }
}
