import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../providers/settings_providers.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});
  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  late final TextEditingController _urlCtrl;

  @override
  void initState() {
    super.initState();
    _urlCtrl = TextEditingController(text: ref.read(serverUrlProvider));
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  static const _styles = ['🟢 محافظ', '🟡 منضبط', '🔴 عدواني'];

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final currentUrl = ref.watch(serverUrlProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _SectionTitle('اتصال السيرفر'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: _urlCtrl,
                    decoration: const InputDecoration(
                      labelText: 'رابط سيرفر FinSMPro (Render)',
                      hintText: 'https://your-app.onrender.com',
                      helperText: '⚠️ هذا رابط السيرفر فقط — وليس رابط قاعدة البيانات. '
                          'قاعدة البيانات تُربط من طرف السيرفر فقط، لا من هنا.',
                      helperMaxLines: 2,
                    ),
                    keyboardType: TextInputType.url,
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          icon: const Icon(Icons.save_outlined, size: 18),
                          label: const Text('حفظ وإعادة الاتصال'),
                          onPressed: () async {
                            try {
                              await ref.read(settingsProvider.notifier).setServerUrl(_urlCtrl.text);
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('تم الحفظ، جاري إعادة الاتصال...')),
                                );
                              }
                            } catch (e) {
                              if (context.mounted) {
                                showDialog(
                                  context: context,
                                  builder: (_) => AlertDialog(
                                    title: const Text('رابط غير صحيح'),
                                    content: Text(e is ArgumentError ? e.message.toString() : '$e'),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.pop(context),
                                        child: const Text('حسناً'),
                                      ),
                                    ],
                                  ),
                                );
                              }
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text('الحالي: $currentUrl',
                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          _SectionTitle('أسلوب التداول'),
          Card(
            child: Column(
              children: _styles
                  .map((s) => RadioListTile<String>(
                        value: s,
                        groupValue: settings.tradingStyle,
                        title: Text(s),
                        onChanged: settings.saving
                            ? null
                            : (v) {
                                if (v != null) {
                                  ref.read(settingsProvider.notifier).setTradingStyle(v);
                                }
                              },
                      ))
                  .toList(),
            ),
          ),
          const SizedBox(height: 20),
          _SectionTitle('محرك القرار'),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('وضع النخبة (Elite Mode)'),
                  subtitle: const Text('تصفية الإشارات لأعلى احتمالية نجاح فقط'),
                  value: settings.eliteMode,
                  onChanged: settings.saving
                      ? null
                      : (v) => ref.read(settingsProvider.notifier).setEliteMode(v),
                ),
                ListTile(
                  leading: Icon(
                    settings.circuitOpen ? Icons.dangerous : Icons.check_circle,
                    color: settings.circuitOpen ? Colors.red : Colors.green,
                  ),
                  title: const Text('قاطع الطوارئ (Circuit Breaker)'),
                  subtitle: Text(settings.circuitOpen
                      ? 'مفتوح — التداول الآلي متوقف مؤقتاً'
                      : 'مغلق — التداول يعمل بشكل طبيعي'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: TextButton.icon(
              onPressed: () => ref.read(settingsProvider.notifier).refresh(),
              icon: const Icon(Icons.refresh, size: 16),
              label: const Text('تحديث الحالة من السيرفر'),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8, right: 4),
        child: Text(text,
            style: TextStyle(
                fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
      );
}
