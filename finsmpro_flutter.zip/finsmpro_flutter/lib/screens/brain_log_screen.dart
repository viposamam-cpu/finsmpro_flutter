import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/brain_entry.dart';
import '../providers/brain_providers.dart';

class BrainLogScreen extends ConsumerStatefulWidget {
  const BrainLogScreen({super.key});
  @override
  ConsumerState<BrainLogScreen> createState() => _BrainLogScreenState();
}

class _BrainLogScreenState extends ConsumerState<BrainLogScreen> {
  final _scrollCtrl = ScrollController();
  bool _autoScroll = true;

  void _jumpToBottom() {
    if (!_scrollCtrl.hasClients) return;
    _scrollCtrl.animateTo(
      _scrollCtrl.position.maxScrollExtent,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    final entries = ref.watch(brainLogProvider);
    final importantOnly = ref.watch(brainImportantOnlyProvider);
    final shown = importantOnly ? entries.where((e) => e.isImportant).toList() : entries;

    ref.listen(brainLogProvider, (prev, next) {
      if (_autoScroll) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _jumpToBottom());
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('عقل الآلي — سجل حي'),
        actions: [
          IconButton(
            icon: Icon(_autoScroll ? Icons.vertical_align_bottom : Icons.pause),
            tooltip: _autoScroll ? 'التمرير التلقائي مفعّل' : 'متوقف مؤقتاً',
            onPressed: () => setState(() => _autoScroll = !_autoScroll),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                FilterChip(
                  label: const Text('المهم فقط (صفقات/تحذيرات)'),
                  selected: importantOnly,
                  onSelected: (v) =>
                      ref.read(brainImportantOnlyProvider.notifier).state = v,
                ),
                const Spacer(),
                _LiveDot(),
              ],
            ),
          ),
          Expanded(
            child: shown.isEmpty
                ? const Center(child: Text('بانتظار أول فكرة من الآلي...'))
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    itemCount: shown.length,
                    itemBuilder: (_, i) => _BrainTile(entry: shown[i]),
                  ),
          ),
        ],
      ),
    );
  }
}

class _LiveDot extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text('مباشر', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
      ],
    );
  }
}

class _BrainTile extends StatelessWidget {
  const _BrainTile({required this.entry});
  final BrainEntry entry;

  Color get _accent {
    switch (entry.level) {
      case '🟢':
        return Colors.green;
      case '🔴':
        return Colors.red;
      case '⚠️':
        return Colors.orange;
      case '🚨':
        return Colors.red.shade900;
      case '⚡':
        return Colors.amber.shade800;
      default:
        return Colors.grey.shade500;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 3),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: entry.isImportant ? _accent.withOpacity(0.08) : null,
        border: Border(right: BorderSide(color: _accent, width: 3)),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(entry.level, style: const TextStyle(fontSize: 15)),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(entry.msg, style: const TextStyle(fontSize: 13.5)),
                const SizedBox(height: 2),
                Text(
                  entry.sym.isNotEmpty ? '${entry.ts}  •  ${entry.sym}' : entry.ts,
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
