import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/analysis.dart';
import '../models/closed_trade.dart';
import '../providers/analysis_providers.dart';
import '../providers/app_providers.dart';
import '../providers/news_providers.dart';

class AnalysisScreen extends ConsumerWidget {
  const AnalysisScreen({super.key, required this.sym, required this.name});
  final String sym;
  final String name;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(analysisProvider(sym));
    final livePrice = ref.watch(livePricesProvider)[sym];
    final positions = ref.watch(positionsProvider);
    final held = positions.where((p) => p.sym == sym).toList();
    final news = ref.watch(newsProvider(sym));

    return Scaffold(
      appBar: AppBar(
        title: Text('$name ($sym)'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.read(analysisProvider(sym).notifier).refresh(),
          ),
        ],
      ),
      body: state.loading && state.candles.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => ref.read(analysisProvider(sym).notifier).refresh(),
              child: ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  _PriceHeader(sym: sym, livePrice: livePrice?.price, signal: state.signal),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 280,
                    child: state.candles.isEmpty
                        ? const Center(child: Text('لا توجد بيانات شارت بعد'))
                        : _CandleChart(candles: state.candles),
                  ),
                  const SizedBox(height: 16),
                  _TradeActionBar(
                    sym: sym,
                    name: name,
                    currentPrice: livePrice?.price ?? state.signal?.price,
                    defaultSl: state.signal?.sl,
                    defaultTp: state.signal?.tp,
                    heldShares: held.fold<int>(0, (s, p) => s + p.shares),
                  ),
                  const SizedBox(height: 16),
                  if (state.signal != null) _SignalPanel(signal: state.signal!),
                  const SizedBox(height: 16),
                  _NewsSection(news: news),
                ],
              ),
            ),
    );
  }
}

class _PriceHeader extends StatelessWidget {
  const _PriceHeader({required this.sym, required this.livePrice, required this.signal});
  final String sym;
  final double? livePrice;
  final StockSignal? signal;

  @override
  Widget build(BuildContext context) {
    final price = livePrice ?? signal?.price;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(price != null ? price.toStringAsFixed(2) : '---',
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        if (signal != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _hexColor(signal!.color).withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(signal!.signal,
                style: TextStyle(
                    color: _hexColor(signal!.color), fontWeight: FontWeight.bold)),
          ),
      ],
    );
  }
}

Color _hexColor(String hex) {
  var h = hex.replaceAll('#', '');
  if (h.length == 6) h = 'FF$h';
  return Color(int.parse(h, radix: 16));
}

class _CandleChart extends StatelessWidget {
  const _CandleChart({required this.candles});
  final List<Candle> candles;

  @override
  Widget build(BuildContext context) {
    // fl_chart لا يوفر candlestick أصلي — نعرض خط الإغلاق + هاي/لو كظل،
    // وهو كافٍ لعرض الاتجاه على الجوال؛ شارت شموع كامل تفاعلي (TradingView-style)
    // ينتظر مكتبة candlesticks المخصصة، نضيفها لاحقاً إن احتجتها بدقة أعلى.
    final closeSpots = <FlSpot>[];
    double minY = double.infinity, maxY = -double.infinity;
    for (var i = 0; i < candles.length; i++) {
      final c = candles[i];
      closeSpots.add(FlSpot(i.toDouble(), c.close));
      if (c.low < minY) minY = c.low;
      if (c.high > maxY) maxY = c.high;
    }
    final pad = (maxY - minY) * 0.05;

    return LineChart(
      LineChartData(
        minY: minY - pad,
        maxY: maxY + pad,
        gridData: const FlGridData(show: true, drawVerticalLine: false),
        titlesData: const FlTitlesData(
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        lineBarsData: [
          LineChartBarData(
            spots: closeSpots,
            isCurved: false,
            barWidth: 2,
            color: Theme.of(context).colorScheme.primary,
            dotData: const FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.08),
            ),
          ),
        ],
      ),
    );
  }
}

class _SignalPanel extends StatelessWidget {
  const _SignalPanel({required this.signal});
  final StockSignal signal;

  @override
  Widget build(BuildContext context) {
    final rows = <(String, String)>[
      ('وقف الخسارة', signal.sl?.toStringAsFixed(2) ?? '-'),
      ('الهدف', signal.tp?.toStringAsFixed(2) ?? '-'),
      ('RSI', signal.rsi?.toStringAsFixed(1) ?? '-'),
      ('ADX', signal.adx?.toStringAsFixed(1) ?? '-'),
      ('VWAP', signal.vwap?.toStringAsFixed(2) ?? '-'),
      ('النظام (Regime)', signal.regime),
      ('التوافق شراء/بيع', '${signal.confluenceBuy} / ${signal.confluenceSell}'),
      ('النمط', signal.pattern),
      ('حجم Kelly المقترح', '${(signal.kellySize * 100).toStringAsFixed(1)}%'),
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('تفاصيل التحليل', style: TextStyle(fontWeight: FontWeight.bold)),
            const Divider(),
            for (final r in rows)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(r.$1, style: TextStyle(color: Colors.grey.shade600)),
                    Text(r.$2, style: const TextStyle(fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            if (signal.explanation.isNotEmpty) ...[
              const Divider(),
              Text(signal.explanation),
            ],
          ],
        ),
      ),
    );
  }
}

class _TradeActionBar extends ConsumerWidget {
  const _TradeActionBar({
    required this.sym,
    required this.name,
    required this.currentPrice,
    required this.defaultSl,
    required this.defaultTp,
    required this.heldShares,
  });
  final String sym;
  final String name;
  final double? currentPrice;
  final double? defaultSl;
  final double? defaultTp;
  final int heldShares;

  Future<void> _confirmBuy(BuildContext context, WidgetRef ref) async {
    final sharesCtrl = TextEditingController(text: '100');
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('شراء $name'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('السعر الحالي: ${currentPrice?.toStringAsFixed(2) ?? '---'}'),
            const SizedBox(height: 12),
            TextField(
              controller: sharesCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'عدد الأسهم'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true), child: const Text('تأكيد الشراء')),
        ],
      ),
    );
    if (ok != true || currentPrice == null) return;
    final shares = int.tryParse(sharesCtrl.text) ?? 0;
    if (shares <= 0) return;

    try {
      final res = await ref.read(apiProvider).buy(
            sym: sym,
            name: name,
            shares: shares,
            price: currentPrice!,
          );
      if (context.mounted) {
        _showResult(context, res['success'] == true, res['message']?.toString() ?? '');
      }
      ref.read(positionsProvider.notifier).refresh();
    } catch (e) {
      if (context.mounted) _showResult(context, false, 'تعذّر تنفيذ الشراء — تحقق من الاتصال');
    }
  }

  Future<void> _confirmSell(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('بيع $name'),
        content: Text('سيتم بيع كامل المركز ($heldShares سهم) بالسعر الحالي '
            '${currentPrice?.toStringAsFixed(2) ?? "الحي"}.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('تأكيد البيع'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    try {
      final res = await ref.read(apiProvider).sell(sym, price: currentPrice);
      if (context.mounted) {
        _showResult(context, res['success'] == true, res['message']?.toString() ?? '');
      }
      ref.read(positionsProvider.notifier).refresh();
    } catch (e) {
      if (context.mounted) _showResult(context, false, 'تعذّر تنفيذ البيع — تحقق من الاتصال');
    }
  }

  void _showResult(BuildContext context, bool success, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message.isEmpty ? (success ? 'تم بنجاح' : 'حدث خطأ') : message),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final holding = heldShares > 0;
    return Row(
      children: [
        Expanded(
          child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.green),
            icon: const Icon(Icons.add_shopping_cart, size: 18),
            label: const Text('شراء'),
            onPressed: currentPrice == null ? null : () => _confirmBuy(context, ref),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: holding ? Colors.red : Colors.grey),
            icon: const Icon(Icons.sell_outlined, size: 18),
            label: Text(holding ? 'بيع ($heldShares)' : 'لا يوجد مركز'),
            onPressed: holding ? () => _confirmSell(context, ref) : null,
          ),
        ),
      ],
    );
  }
}

class _NewsSection extends StatelessWidget {
  const _NewsSection({required this.news});
  final AsyncValue<List<NewsItem>> news;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('آخر الأخبار', style: TextStyle(fontWeight: FontWeight.bold)),
            const Divider(),
            news.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
              ),
              error: (_, __) =>
                  Text('تعذّر تحميل الأخبار', style: TextStyle(color: Colors.grey.shade600)),
              data: (items) => items.isEmpty
                  ? Text('لا توجد أخبار حالياً', style: TextStyle(color: Colors.grey.shade600))
                  : Column(
                      children: items
                          .take(8)
                          .map((n) => Padding(
                                padding: const EdgeInsets.symmetric(vertical: 6),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(Icons.article_outlined,
                                        size: 16, color: Colors.grey.shade500),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(n.title, style: const TextStyle(fontSize: 13)),
                                          Text('${n.source} • ${n.date}',
                                              style: TextStyle(
                                                  fontSize: 10.5, color: Colors.grey.shade500)),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ))
                          .toList(),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
