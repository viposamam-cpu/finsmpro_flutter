import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/analysis.dart';
import '../providers/analysis_providers.dart';
import '../providers/app_providers.dart';

class AnalysisScreen extends ConsumerWidget {
  const AnalysisScreen({super.key, required this.sym, required this.name});
  final String sym;
  final String name;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(analysisProvider(sym));
    final livePrice = ref.watch(livePricesProvider)[sym];

    return Scaffold(
      appBar: AppBar(
        title: Text('$name ($sym)'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.read(analysisProvider(sym).notifier).refresh(),
          ),
        ],
      ),
      body: state.loading && state.candles.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => ref.read(analysisProvider(sym).notifier).refresh(),
              child: ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  _PriceHeader(sym: sym, livePrice: livePrice?.price, signal: state.signal),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 280,
                    child: state.candles.isEmpty
                        ? const Center(child: Text('لا توجد بيانات شارت بعد'))
                        : _CandleChart(candles: state.candles),
                  ),
                  const SizedBox(height: 16),
                  if (state.signal != null) _SignalPanel(signal: state.signal!),
                ],
              ),
            ),
    );
  }
}

class _PriceHeader extends StatelessWidget {
  const _PriceHeader({required this.sym, required this.livePrice, required this.signal});
  final String sym;
  final double? livePrice;
  final StockSignal? signal;

  @override
  Widget build(BuildContext context) {
    final price = livePrice ?? signal?.price;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(price != null ? price.toStringAsFixed(2) : '---',
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        if (signal != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _hexColor(signal!.color).withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(signal!.signal,
                style: TextStyle(
                    color: _hexColor(signal!.color), fontWeight: FontWeight.bold)),
          ),
      ],
    );
  }
}

Color _hexColor(String hex) {
  var h = hex.replaceAll('#', '');
  if (h.length == 6) h = 'FF$h';
  return Color(int.parse(h, radix: 16));
}

class _CandleChart extends StatelessWidget {
  const _CandleChart({required this.candles});
  final List<Candle> candles;

  @override
  Widget build(BuildContext context) {
    // fl_chart لا يوفر candlestick أصلي — نعرض خط الإغلاق + هاي/لو كظل،
    // وهو كافٍ لعرض الاتجاه على الجوال؛ شارت شموع كامل تفاعلي (TradingView-style)
    // ينتظر مكتبة candlesticks المخصصة، نضيفها لاحقاً إن احتجتها بدقة أعلى.
    final closeSpots = <FlSpot>[];
    double minY = double.infinity, maxY = -double.infinity;
    for (var i = 0; i < candles.length; i++) {
      final c = candles[i];
      closeSpots.add(FlSpot(i.toDouble(), c.close));
      if (c.low < minY) minY = c.low;
      if (c.high > maxY) maxY = c.high;
    }
    final pad = (maxY - minY) * 0.05;

    return LineChart(
      LineChartData(
        minY: minY - pad,
        maxY: maxY + pad,
        gridData: const FlGridData(show: true, drawVerticalLine: false),
        titlesData: const FlTitlesData(
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        lineBarsData: [
          LineChartBarData(
            spots: closeSpots,
            isCurved: false,
            barWidth: 2,
            color: Theme.of(context).colorScheme.primary,
            dotData: const FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.08),
            ),
          ),
        ],
      ),
    );
  }
}

class _SignalPanel extends StatelessWidget {
  const _SignalPanel({required this.signal});
  final StockSignal signal;

  @override
  Widget build(BuildContext context) {
    final rows = <(String, String)>[
      ('وقف الخسارة', signal.sl?.toStringAsFixed(2) ?? '-'),
      ('الهدف', signal.tp?.toStringAsFixed(2) ?? '-'),
      ('RSI', signal.rsi?.toStringAsFixed(1) ?? '-'),
      ('ADX', signal.adx?.toStringAsFixed(1) ?? '-'),
      ('VWAP', signal.vwap?.toStringAsFixed(2) ?? '-'),
      ('النظام (Regime)', signal.regime),
      ('التوافق شراء/بيع', '${signal.confluenceBuy} / ${signal.confluenceSell}'),
      ('النمط', signal.pattern),
      ('حجم Kelly المقترح', '${(signal.kellySize * 100).toStringAsFixed(1)}%'),
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('تفاصيل التحليل', style: TextStyle(fontWeight: FontWeight.bold)),
            const Divider(),
            for (final r in rows)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(r.$1, style: TextStyle(color: Colors.grey.shade600)),
                    Text(r.$2, style: const TextStyle(fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            if (signal.explanation.isNotEmpty) ...[
              const Divider(),
              Text(signal.explanation),
            ],
          ],
        ),
      ),
    );
  }
}
