import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import 'portfolio_screen.dart';
import 'watchlist_screen.dart';
import 'risk_screen.dart';
import 'brain_log_screen.dart';
import 'chat_screen.dart';

class RootShell extends ConsumerStatefulWidget {
  const RootShell({super.key});
  @override
  ConsumerState<RootShell> createState() => _RootShellState();
}

class _RootShellState extends ConsumerState<RootShell> {
  int _index = 0;

  static const _screens = [
    PortfolioScreen(),
    WatchlistScreen(),
    RiskScreen(),
    BrainLogScreen(),
    ChatScreen(),
  ];

  @override
  void initState() {
    super.initState();
    // ابدأ خدمة مزامنة العمليات المعلّقة أوفلاين مع بداية التطبيق،
    // وحدّث المؤشر بالشريط العلوي كلما تغيّر عدد العمليات المعلّقة
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(syncServiceProvider).status.listen((s) {
        ref.read(pendingOpsCountProvider.notifier).state = s.pending;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final pending = ref.watch(pendingOpsCountProvider);

    return Scaffold(
      body: Column(
        children: [
          if (pending > 0) _PendingBanner(count: pending),
          Expanded(child: IndexedStack(index: _index, children: _screens)),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.pie_chart_outline), label: 'المحفظة'),
          NavigationDestination(icon: Icon(Icons.visibility_outlined), label: 'المراقبة'),
          NavigationDestination(icon: Icon(Icons.shield_outlined), label: 'المخاطر'),
          NavigationDestination(icon: Icon(Icons.psychology_outlined), label: 'عقل الآلي'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'الشات'),
        ],
      ),
    );
  }
}

class _PendingBanner extends ConsumerWidget {
  const _PendingBanner({required this.count});
  final int count;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Material(
      color: Colors.orange.shade50,
      child: InkWell(
        onTap: () => ref.read(syncServiceProvider).flushNow(),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              Icon(Icons.cloud_off, size: 16, color: Colors.orange.shade800),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '$count عملية بانتظار المزامنة — سيُعاد إرسالها تلقائياً عند عودة الاتصال',
                  style: TextStyle(fontSize: 12, color: Colors.orange.shade900),
                ),
              ),
              Icon(Icons.refresh, size: 16, color: Colors.orange.shade800),
            ],
          ),
        ),
      ),
    );
  }
}
