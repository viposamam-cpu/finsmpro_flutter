import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/portfolio_summary.dart';
import '../providers/risk_providers.dart';

class RiskScreen extends ConsumerWidget {
  const RiskScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(riskScreenProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('المحفظة والمخاطر'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.read(riskScreenProvider.notifier).refresh(),
          ),
        ],
      ),
      body: state.loading && state.portfolio == null
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => ref.read(riskScreenProvider.notifier).refresh(),
              child: ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  if (state.portfolio != null) _PortfolioCard(p: state.portfolio!),
                  const SizedBox(height: 12),
                  if (state.risk != null) _RiskCard(risk: state.risk!),
                  const SizedBox(height: 12),
                  if (state.portfolio?.ensembleAdvice != null)
                    _AdviceCard(
                      title: 'رأي مجلس الذكاء الاصطناعي — المحفظة',
                      text: state.portfolio!.ensembleAdvice!,
                      icon: Icons.groups_2_outlined,
                    ),
                  if (state.risk?.ensembleAssessment != null) ...[
                    const SizedBox(height: 12),
                    _AdviceCard(
                      title: 'تقييم المخاطر — تفصيلي',
                      text: state.risk!.ensembleAssessment!,
                      icon: Icons.shield_outlined,
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}

class _PortfolioCard extends StatelessWidget {
  const _PortfolioCard({required this.p});
  final PortfolioSummary p;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ملخص المحفظة', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _stat('الإجمالي (Equity)', p.equity.toStringAsFixed(0)),
                _stat('النقدي المتاح', p.cash.toStringAsFixed(0)),
                _stat('عدد المراكز', '${p.positionsCount}'),
              ],
            ),
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: (p.investedPct / 100).clamp(0, 1),
                minHeight: 8,
                backgroundColor: Colors.grey.shade200,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'نسبة الأموال المستثمرة: ${p.investedPct.toStringAsFixed(1)}%',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) => Column(
        children: [
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
        ],
      );
}

class _RiskCard extends StatelessWidget {
  const _RiskCard({required this.risk});
  final RiskAssessment risk;

  (Color, String) _levelStyle() {
    switch (risk.riskLevel) {
      case 'high':
        return (Colors.red, 'مرتفع');
      case 'medium':
        return (Colors.orange, 'متوسط');
      default:
        return (Colors.green, 'منخفض');
    }
  }

  @override
  Widget build(BuildContext context) {
    final (color, label) = _levelStyle();
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.15),
          child: Icon(Icons.warning_amber_rounded, color: color),
        ),
        title: const Text('مستوى المخاطر الحالي'),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }
}

class _AdviceCard extends StatelessWidget {
  const _AdviceCard({required this.title, required this.text, required this.icon});
  final String title;
  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 18, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 8),
            Text(text, style: TextStyle(color: Colors.grey.shade800, height: 1.5)),
          ],
        ),
      ),
    );
  }
}
