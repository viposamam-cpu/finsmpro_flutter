import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/position.dart';
import '../models/price_snapshot.dart';
import '../providers/app_providers.dart';
import 'analysis_screen.dart';
import 'settings_screen.dart';

class PortfolioScreen extends ConsumerStatefulWidget {
  const PortfolioScreen({super.key});
  @override
  ConsumerState<PortfolioScreen> createState() => _PortfolioScreenState();
}

class _PortfolioScreenState extends ConsumerState<PortfolioScreen> {
  @override
  Widget build(BuildContext context) {
    final positions = ref.watch(positionsProvider);
    final prices = ref.watch(livePricesProvider);

    // أخبر خدمة الأسعار الحية بالرموز المعروضة حالياً فقط
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(priceStreamProvider).watchSymbols(
            positions.map((p) => p.sym).toList(),
          );
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('المحفظة — FinSMPro Omega'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.read(positionsProvider.notifier).refresh(),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: positions.isEmpty
          ? const Center(child: Text('لا توجد مراكز مفتوحة حالياً'))
          : RefreshIndicator(
              onRefresh: () => ref.read(positionsProvider.notifier).refresh(),
              child: ListView.separated(
                itemCount: positions.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) =>
                    _PositionTile(position: positions[i], snap: prices[positions[i].sym]),
              ),
            ),
    );
  }
}

class _PositionTile extends StatelessWidget {
  const _PositionTile({required this.position, required this.snap});
  final Position position;
  final PriceSnapshot? snap;

  @override
  Widget build(BuildContext context) {
    final price = snap?.price ?? position.entry;
    final pnlPct =
        position.entry > 0 ? ((price - position.entry) / position.entry * 100) : 0.0;
    final isUp = pnlPct >= 0;
    final live = snap != null && snap!.isLive && snap!.ageSeconds < 10;

    return ListTile(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => AnalysisScreen(sym: position.sym, name: position.name),
      )),
      leading: CircleAvatar(
        backgroundColor: live ? Colors.green.shade50 : Colors.grey.shade200,
        child: Icon(live ? Icons.podcasts : Icons.schedule,
            color: live ? Colors.green : Colors.grey, size: 18),
      ),
      title: Text('${position.name} (${position.sym})',
          style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(snap == null
          ? 'بانتظار السعر...'
          : 'المصدر: ${snap!.source} • قبل ${snap!.ageSeconds} ث'),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(price.toStringAsFixed(2),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Text('${isUp ? '+' : ''}${pnlPct.toStringAsFixed(2)}%',
              style: TextStyle(
                  color: isUp ? Colors.green : Colors.red,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
