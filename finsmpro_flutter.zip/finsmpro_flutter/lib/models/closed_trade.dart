/// يطابق أعمدة جدول closed_trades الفعلية بالسيرفر (ts, sym, name,
/// buy_price, sell_price, shares, pnl, pnl_pct, commission, net_pnl,
/// duration, manual) — وليس الحقول الافتراضية التي خمّنتها سابقاً
class ClosedTrade {
  final String ts;
  final String sym;
  final String name;
  final double buyPrice;
  final double sellPrice;
  final int shares;
  final double pnl;
  final double pnlPct;
  final double commission;
  final double netPnl;
  final String duration;
  final bool manual;

  const ClosedTrade({
    required this.ts,
    required this.sym,
    required this.name,
    required this.buyPrice,
    required this.sellPrice,
    required this.shares,
    required this.pnl,
    required this.pnlPct,
    this.commission = 0,
    required this.netPnl,
    this.duration = '',
    this.manual = false,
  });

  bool get isWin => netPnl >= 0;

  factory ClosedTrade.fromJson(Map<String, dynamic> j) => ClosedTrade(
        ts: j['ts']?.toString() ?? '',
        sym: j['sym']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        buyPrice: (j['buy_price'] as num?)?.toDouble() ?? 0,
        sellPrice: (j['sell_price'] as num?)?.toDouble() ?? 0,
        shares: (j['shares'] as num?)?.toInt() ?? 0,
        pnl: (j['pnl'] as num?)?.toDouble() ?? 0,
        pnlPct: (j['pnl_pct'] as num?)?.toDouble() ?? 0,
        commission: (j['commission'] as num?)?.toDouble() ?? 0,
        netPnl: (j['net_pnl'] as num?)?.toDouble() ?? (j['pnl'] as num?)?.toDouble() ?? 0,
        duration: j['duration']?.toString() ?? '',
        manual: j['manual'] == 1 || j['manual'] == true,
      );

  factory ClosedTrade.fromDb(Map<String, dynamic> m) => ClosedTrade(
        ts: m['ts'] ?? '',
        sym: m['sym'] ?? '',
        name: m['name'] ?? '',
        buyPrice: (m['buy_price'] as num?)?.toDouble() ?? 0,
        sellPrice: (m['sell_price'] as num?)?.toDouble() ?? 0,
        shares: (m['shares'] as num?)?.toInt() ?? 0,
        pnl: (m['pnl'] as num?)?.toDouble() ?? 0,
        pnlPct: (m['pnl_pct'] as num?)?.toDouble() ?? 0,
        commission: (m['commission'] as num?)?.toDouble() ?? 0,
        netPnl: (m['net_pnl'] as num?)?.toDouble() ?? 0,
        duration: m['duration'] ?? '',
        manual: m['manual'] == 1,
      );

  Map<String, dynamic> toDb() => {
        'ts': ts,
        'sym': sym,
        'name': name,
        'buy_price': buyPrice,
        'sell_price': sellPrice,
        'shares': shares,
        'pnl': pnl,
        'pnl_pct': pnlPct,
        'commission': commission,
        'net_pnl': netPnl,
        'duration': duration,
        'manual': manual ? 1 : 0,
      };
}

/// عنصر خبر واحد من /api/news — الحقول الفعلية: title, date, source, url, sym
class NewsItem {
  final String title;
  final String url;
  final String source;
  final String date;
  final String sym;

  const NewsItem(
      {required this.title, required this.url, this.source = '', this.date = '', this.sym = ''});

  factory NewsItem.fromJson(Map<String, dynamic> j) => NewsItem(
        title: j['title'] ?? '',
        url: j['url'] ?? '#',
        source: j['source'] ?? '',
        date: j['date']?.toString() ?? '',
        sym: j['sym']?.toString() ?? '',
      );
}
