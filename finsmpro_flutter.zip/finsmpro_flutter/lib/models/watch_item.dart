/// عنصر واحد بنتيجة /api/watchlist_scan
class WatchItem {
  final String sym;
  final String name;
  final double? price;
  final String signal;
  final String color;
  final double? sl, tp;

  const WatchItem({
    required this.sym,
    required this.name,
    this.price,
    this.signal = 'مراقبة',
    this.color = '#94a3b8',
    this.sl,
    this.tp,
  });

  factory WatchItem.fromJson(Map<String, dynamic> j) => WatchItem(
        sym: j['sym'] ?? '',
        name: j['name'] ?? '',
        price: (j['price'] as num?)?.toDouble(),
        signal: j['signal'] ?? 'مراقبة',
        color: j['color'] ?? '#94a3b8',
        sl: (j['sl'] as num?)?.toDouble(),
        tp: (j['tp'] as num?)?.toDouble(),
      );

  factory WatchItem.fromDb(Map<String, dynamic> m) => WatchItem(
        sym: m['sym'],
        name: m['name'] ?? '',
        price: (m['price'] as num?)?.toDouble(),
        signal: m['signal'] ?? 'مراقبة',
        color: m['color'] ?? '#94a3b8',
        sl: (m['sl'] as num?)?.toDouble(),
        tp: (m['tp'] as num?)?.toDouble(),
      );

  Map<String, dynamic> toDb() => {
        'sym': sym,
        'name': name,
        'price': price,
        'signal': signal,
        'color': color,
        'sl': sl,
        'tp': tp,
      };

  /// هل الإشارة شراء؟ (يُستخدم للفرز/الفلترة بالشاشة)
  bool get isBuy => signal.contains('شراء');
  bool get isSell => signal.contains('بيع');
}
