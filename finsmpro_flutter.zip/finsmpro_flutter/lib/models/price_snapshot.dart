/// يطابق dict الذي يعيده get_price_data / get_price_data_cached في السيرفر
class PriceSnapshot {
  final String sym;
  final double? price;
  final double? last;
  final double? prevClose;
  final double? close;
  final double change;
  final double changePct;
  final bool isLive;
  final String source; // tv_webhook | intraday_1m | close | daily_stale ...
  final String barTime;
  final bool stale;
  final int updatedAtMs; // وقت الاستلام محلياً على الجهاز (epoch ms)

  const PriceSnapshot({
    required this.sym,
    this.price,
    this.last,
    this.prevClose,
    this.close,
    this.change = 0,
    this.changePct = 0,
    this.isLive = false,
    this.source = 'none',
    this.barTime = '',
    this.stale = true,
    required this.updatedAtMs,
  });

  /// عمر البيانات بالثواني منذ آخر تحديث فعلي وصل للجهاز
  int get ageSeconds =>
      ((DateTime.now().millisecondsSinceEpoch - updatedAtMs) / 1000).round();

  factory PriceSnapshot.fromJson(String sym, Map<String, dynamic> j) =>
      PriceSnapshot(
        sym: sym,
        price: (j['price'] as num?)?.toDouble(),
        last: (j['last'] as num?)?.toDouble(),
        prevClose: (j['prev_close'] as num?)?.toDouble(),
        close: (j['close'] as num?)?.toDouble(),
        change: (j['change'] as num?)?.toDouble() ?? 0,
        changePct: (j['change_pct'] as num?)?.toDouble() ?? 0,
        isLive: j['is_live'] == true,
        source: j['source'] ?? 'none',
        barTime: j['bar_time'] ?? '',
        stale: j['stale'] == true,
        updatedAtMs: DateTime.now().millisecondsSinceEpoch,
      );

  factory PriceSnapshot.fromDb(Map<String, dynamic> m) => PriceSnapshot(
        sym: m['sym'],
        price: (m['price'] as num?)?.toDouble(),
        last: (m['last_px'] as num?)?.toDouble(),
        prevClose: (m['prev_close'] as num?)?.toDouble(),
        close: (m['close'] as num?)?.toDouble(),
        change: (m['change'] as num?)?.toDouble() ?? 0,
        changePct: (m['change_pct'] as num?)?.toDouble() ?? 0,
        isLive: m['is_live'] == 1,
        source: m['source'] ?? 'none',
        barTime: m['bar_time'] ?? '',
        stale: m['stale'] == 1,
        updatedAtMs: (m['updated_at'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
      );

  Map<String, dynamic> toDb() => {
        'sym': sym,
        'price': price,
        'last_px': last,
        'prev_close': prevClose,
        'close': close,
        'change': change,
        'change_pct': changePct,
        'is_live': isLive ? 1 : 0,
        'source': source,
        'bar_time': barTime,
        'stale': stale ? 1 : 0,
        'updated_at': updatedAtMs,
      };
}
