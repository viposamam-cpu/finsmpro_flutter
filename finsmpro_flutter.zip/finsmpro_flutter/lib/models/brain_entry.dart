/// يطابق entry الذي يبثّه BrainLog.think() عبر /api/brain_stream
/// وأيضاً /api/brain (آخر السجل عند فتح الشاشة أول مرة)
class BrainEntry {
  final int id;
  final String ts; // HH:mm:ss
  final String tsFull;
  final String level; // 💭 📊 ⚡ 🟢 🔴 ⚠️ 🚨
  final String sym;
  final String msg;
  final Map<String, dynamic> data;

  const BrainEntry({
    required this.id,
    required this.ts,
    required this.tsFull,
    required this.level,
    required this.sym,
    required this.msg,
    this.data = const {},
  });

  factory BrainEntry.fromJson(Map<String, dynamic> j) => BrainEntry(
        id: (j['id'] as num?)?.toInt() ?? 0,
        ts: j['ts'] ?? '',
        tsFull: j['ts_full'] ?? '',
        level: j['level'] ?? '💭',
        sym: j['sym'] ?? '',
        msg: j['msg'] ?? '',
        data: (j['data'] as Map?)?.cast<String, dynamic>() ?? const {},
      );

  /// أولوية العرض — نفس ترتيب LEVELS بالسيرفر
  int get priority => const {
        '💭': 0,
        '📊': 1,
        '⚡': 2,
        '🟢': 3,
        '🔴': 3,
        '⚠️': 4,
        '🚨': 5,
      }[level] ??
      0;

  bool get isImportant => priority >= 3; // صفقة/تحذير/طارئ
}
