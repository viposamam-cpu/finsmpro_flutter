/// يطابق كائن candle الذي يعيده /api/chart_data
class Candle {
  final int time; // epoch seconds
  final double open, high, low, close;
  final int volume;

  const Candle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  factory Candle.fromJson(Map<String, dynamic> j) => Candle(
        time: (j['time'] as num).toInt(),
        open: (j['open'] as num).toDouble(),
        high: (j['high'] as num).toDouble(),
        low: (j['low'] as num).toDouble(),
        close: (j['close'] as num).toDouble(),
        volume: (j['volume'] as num?)?.toInt() ?? 0,
      );

  DateTime get dateTime =>
      DateTime.fromMillisecondsSinceEpoch(time * 1000, isUtc: true)
          .toLocal();
}

/// نقطة دخول/خروج مرسومة على الشارت (من positions)
class ChartMarker {
  final int time;
  final String text;
  final String color;

  const ChartMarker({required this.time, required this.text, required this.color});

  factory ChartMarker.fromJson(Map<String, dynamic> j) => ChartMarker(
        time: (j['time'] as num).toInt(),
        text: j['text'] ?? '',
        color: j['color'] ?? '#22c55e',
      );
}

/// يطابق الحقول الأساسية التي يعيدها get_stock_signal عبر /api/analyze
class StockSignal {
  final String signal; // "شراء 🟢" / "بيع 🔴" / "مراقبة ⏸️" ...
  final String color; // hex
  final double? sl, tp;
  final int strength;
  final double? rsi, atr, adx, vwap, pivot, stochK, bbPct;
  final String regime;
  final int confluenceBuy, confluenceSell;
  final String pattern;
  final double kellySize;
  final String entryType;
  final double? price;
  final String explanation;

  const StockSignal({
    required this.signal,
    required this.color,
    this.sl,
    this.tp,
    this.strength = 0,
    this.rsi,
    this.atr,
    this.adx,
    this.vwap,
    this.pivot,
    this.stochK,
    this.bbPct,
    this.regime = 'Normal',
    this.confluenceBuy = 0,
    this.confluenceSell = 0,
    this.pattern = 'لا يوجد',
    this.kellySize = 0,
    this.entryType = 'انتظار',
    this.price,
    this.explanation = '',
  });

  factory StockSignal.fromJson(Map<String, dynamic> j) => StockSignal(
        signal: j['signal'] ?? 'مراقبة ⏸️',
        color: j['color'] ?? '#64748b',
        sl: (j['sl'] as num?)?.toDouble(),
        tp: (j['tp'] as num?)?.toDouble(),
        strength: (j['strength'] as num?)?.toInt() ?? 0,
        rsi: (j['rsi'] as num?)?.toDouble(),
        atr: (j['atr'] as num?)?.toDouble(),
        adx: (j['adx'] as num?)?.toDouble(),
        vwap: (j['vwap'] as num?)?.toDouble(),
        pivot: (j['pivot'] as num?)?.toDouble(),
        stochK: (j['stoch_k'] as num?)?.toDouble(),
        bbPct: (j['bb_pct'] as num?)?.toDouble(),
        regime: j['regime'] ?? 'Normal',
        confluenceBuy: (j['confluence_buy'] as num?)?.toInt() ?? 0,
        confluenceSell: (j['confluence_sell'] as num?)?.toInt() ?? 0,
        pattern: j['pattern'] ?? 'لا يوجد',
        kellySize: (j['kelly_size'] as num?)?.toDouble() ?? 0,
        entryType: j['entry_type'] ?? 'انتظار',
        price: (j['price'] as num?)?.toDouble(),
        explanation: j['explanation'] ?? '',
      );
}
