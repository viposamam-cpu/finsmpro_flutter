/// يطابق تماماً @dataclass Position في finsmpro_v55_server.py (سطر ~665)
class Position {
  final String sym;
  final String name;
  final int shares;
  final double entry;
  final double sl;
  final double tp;
  final String tf; // الإطار الزمني: 1D, 1H ...
  final String opened; // تاريخ الفتح ISO
  final int manual; // 1 = شراء يدوي (لا يبيعه إلا المستخدم) | 0 = آلي

  const Position({
    required this.sym,
    required this.name,
    required this.shares,
    required this.entry,
    required this.sl,
    required this.tp,
    this.tf = '1D',
    required this.opened,
    this.manual = 0,
  });

  factory Position.fromJson(Map<String, dynamic> j) => Position(
        sym: j['sym'] ?? '',
        name: j['name'] ?? '',
        shares: (j['shares'] ?? 0) as int,
        entry: (j['entry'] ?? 0).toDouble(),
        sl: (j['sl'] ?? 0).toDouble(),
        tp: (j['tp'] ?? 0).toDouble(),
        tf: j['tf'] ?? '1D',
        opened: j['opened'] ?? '',
        manual: (j['manual'] ?? 0) as int,
      );

  Map<String, dynamic> toJson() => {
        'sym': sym,
        'name': name,
        'shares': shares,
        'entry': entry,
        'sl': sl,
        'tp': tp,
        'tf': tf,
        'opened': opened,
        'manual': manual,
      };

  factory Position.fromDb(Map<String, dynamic> m) => Position.fromJson(m);
  Map<String, dynamic> toDb() => toJson();
}
