/// رسالة واحدة بمحادثة الشات مع AI — محفوظة محلياً بشكل كامل
/// (تاريخ المحادثة يبقى بالجهاز حتى بدون إنترنت)
class ChatMessage {
  final int? id;
  final String text;
  final bool isUser; // true = المستخدم، false = رد AI
  final String model; // openrouter-claude, openrouter-deepseek ...
  final String sym; // السهم المرتبط بسياق السؤال (إن وجد)
  final int ts; // epoch ms
  final bool failed; // فشل الإرسال (بانتظار إعادة المحاولة)

  const ChatMessage({
    this.id,
    required this.text,
    required this.isUser,
    this.model = 'openrouter-claude',
    this.sym = '',
    required this.ts,
    this.failed = false,
  });

  ChatMessage copyWith({bool? failed}) => ChatMessage(
        id: id,
        text: text,
        isUser: isUser,
        model: model,
        sym: sym,
        ts: ts,
        failed: failed ?? this.failed,
      );

  factory ChatMessage.fromDb(Map<String, dynamic> m) => ChatMessage(
        id: m['id'] as int?,
        text: m['text'] ?? '',
        isUser: m['is_user'] == 1,
        model: m['model'] ?? 'openrouter-claude',
        sym: m['sym'] ?? '',
        ts: (m['ts'] as num?)?.toInt() ?? 0,
        failed: m['failed'] == 1,
      );

  Map<String, dynamic> toDb() => {
        'text': text,
        'is_user': isUser ? 1 : 0,
        'model': model,
        'sym': sym,
        'ts': ts,
        'failed': failed ? 1 : 0,
      };
}
