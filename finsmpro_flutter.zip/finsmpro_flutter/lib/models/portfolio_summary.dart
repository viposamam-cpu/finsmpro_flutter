/// يطابق dict الذي يعيده db_get_portfolio(): {cash, equity}
class PortfolioSummary {
  final double cash;
  final double equity;
  final int positionsCount;
  final String? ensembleAdvice;

  const PortfolioSummary({
    required this.cash,
    required this.equity,
    this.positionsCount = 0,
    this.ensembleAdvice,
  });

  double get invested => equity - cash;
  double get investedPct => equity > 0 ? (invested / equity * 100) : 0;

  factory PortfolioSummary.fromJson(Map<String, dynamic> j) {
    final port = (j['portfolio'] as Map<String, dynamic>?) ?? j;
    return PortfolioSummary(
      cash: (port['cash'] as num?)?.toDouble() ?? 0,
      equity: (port['equity'] as num?)?.toDouble() ?? 0,
      positionsCount: (j['positions'] as num?)?.toInt() ?? 0,
      ensembleAdvice: j['ensemble_advice']?.toString(),
    );
  }

  factory PortfolioSummary.fromDb(Map<String, dynamic> m) => PortfolioSummary(
        cash: (m['cash'] as num?)?.toDouble() ?? 0,
        equity: (m['equity'] as num?)?.toDouble() ?? 0,
        positionsCount: (m['positions_count'] as num?)?.toInt() ?? 0,
        ensembleAdvice: m['ensemble_advice'],
      );

  Map<String, dynamic> toDb() => {
        'cash': cash,
        'equity': equity,
        'positions_count': positionsCount,
        'ensemble_advice': ensembleAdvice,
      };
}

/// يطابق dict الذي يعيده /api/risk_analysis
class RiskAssessment {
  final String riskLevel; // low | medium | high
  final String? ensembleAssessment;

  const RiskAssessment({required this.riskLevel, this.ensembleAssessment});

  factory RiskAssessment.fromJson(Map<String, dynamic> j) => RiskAssessment(
        riskLevel: j['risk_level'] ?? 'low',
        ensembleAssessment: j['ensemble_assessment']?.toString(),
      );

  factory RiskAssessment.fromDb(Map<String, dynamic> m) => RiskAssessment(
        riskLevel: m['risk_level'] ?? 'low',
        ensembleAssessment: m['ensemble_assessment'],
      );

  Map<String, dynamic> toDb() =>
      {'risk_level': riskLevel, 'ensemble_assessment': ensembleAssessment};
}
