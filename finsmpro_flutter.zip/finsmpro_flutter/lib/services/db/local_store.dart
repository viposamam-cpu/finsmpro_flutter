import 'dart:convert';
import '../../models/position.dart';
import '../../models/price_snapshot.dart';
import '../../models/analysis.dart';
import '../../models/watch_item.dart';
import '../../models/portfolio_summary.dart';
import '../../models/brain_entry.dart';
import '../../models/chat_message.dart';
import 'app_database.dart';

/// طبقة وصول موحّدة للتخزين المحلي — كل الشاشات تقرأ/تكتب من هنا فقط،
/// حتى لا يتكرر منطق SQLite في كل شاشة (نفس مبدأ عدم التكرار في السيرفر).
class LocalStore {
  LocalStore._();
  static final LocalStore instance = LocalStore._();

  // ---------------- المراكز المفتوحة ----------------
  Future<void> upsertPositions(List<Position> items) async {
    final db = await AppDatabase.instance.db;
    final batch = db.batch();
    for (final p in items) {
      batch.insert('positions', p.toDb());
    }
    await batch.commit(noResult: true);
  }

  Future<List<Position>> getPositions() async {
    final db = await AppDatabase.instance.db;
    final rows = await db.query('positions', orderBy: 'opened DESC');
    return rows.map(Position.fromDb).toList();
  }

  Future<void> removePosition(String sym) async {
    final db = await AppDatabase.instance.db;
    await db.delete('positions', where: 'sym = ?', whereArgs: [sym]);
  }

  // ---------------- كاش الأسعار الحية ----------------
  Future<void> upsertPrice(PriceSnapshot p) async {
    final db = await AppDatabase.instance.db;
    await db.insert('price_cache', p.toDb());
  }

  Future<PriceSnapshot?> getPrice(String sym) async {
    final db = await AppDatabase.instance.db;
    final rows =
        await db.query('price_cache', where: 'sym = ?', whereArgs: [sym]);
    if (rows.isEmpty) return null;
    return PriceSnapshot.fromDb(rows.first);
  }

  Future<Map<String, PriceSnapshot>> getAllPrices() async {
    final db = await AppDatabase.instance.db;
    final rows = await db.query('price_cache');
    return {for (final r in rows) r['sym'] as String: PriceSnapshot.fromDb(r)};
  }

  // ---------------- عمليات معلّقة (أوفلاين) ----------------
  Future<void> queuePendingOp(
      String endpoint, String method, String bodyJson) async {
    final db = await AppDatabase.instance.db;
    await db.insert('pending_ops', {
      'endpoint': endpoint,
      'method': method,
      'body_json': bodyJson,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<Map<String, dynamic>>> getPendingOps() async {
    final db = await AppDatabase.instance.db;
    return db.query('pending_ops', orderBy: 'created_at ASC');
  }

  Future<void> clearPendingOp(int id) async {
    final db = await AppDatabase.instance.db;
    await db.delete('pending_ops', where: 'id = ?', whereArgs: [id]);
  }

  // ---------------- كاش شموع الشارت ----------------
  Future<void> upsertCandles(String sym, String tf, List<Candle> candles) async {
    final db = await AppDatabase.instance.db;
    final batch = db.batch();
    for (final c in candles) {
      batch.insert('candles_cache', {
        'sym': sym,
        'tf': tf,
        'time': c.time,
        'open': c.open,
        'high': c.high,
        'low': c.low,
        'close': c.close,
        'volume': c.volume,
      });
    }
    await batch.commit(noResult: true);
  }

  Future<List<Candle>> getCandles(String sym, String tf) async {
    final db = await AppDatabase.instance.db;
    final rows = await db.query('candles_cache',
        where: 'sym = ? AND tf = ?', whereArgs: [sym, tf], orderBy: 'time ASC');
    return rows
        .map((r) => Candle(
              time: r['time'] as int,
              open: r['open'] as double,
              high: r['high'] as double,
              low: r['low'] as double,
              close: r['close'] as double,
              volume: (r['volume'] as num?)?.toInt() ?? 0,
            ))
        .toList();
  }

  // ---------------- كاش الإشارة/التحليل ----------------
  Future<void> setSignal(String sym, Map<String, dynamic> json) async {
    final db = await AppDatabase.instance.db;
    await db.insert('signal_cache', {
      'sym': sym,
      'json': jsonEncode(json),
      'updated_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<StockSignal?> getSignal(String sym) async {
    final db = await AppDatabase.instance.db;
    final rows = await db.query('signal_cache', where: 'sym = ?', whereArgs: [sym]);
    if (rows.isEmpty) return null;
    return StockSignal.fromJson(jsonDecode(rows.first['json'] as String));
  }

  // ---------------- كاش قائمة المراقبة الكاملة ----------------
  Future<void> upsertWatchScan(List<WatchItem> items) async {
    final db = await AppDatabase.instance.db;
    final batch = db.batch();
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final it in items) {
      batch.insert('watchlist_scan_cache', {...it.toDb(), 'updated_at': now});
    }
    await batch.commit(noResult: true);
  }

  Future<List<WatchItem>> getWatchScan() async {
    final db = await AppDatabase.instance.db;
    final rows = await db.query('watchlist_scan_cache', orderBy: 'sym ASC');
    return rows.map(WatchItem.fromDb).toList();
  }

  // ---------------- كاش ملخص المحفظة وتقييم المخاطر ----------------
  Future<void> setPortfolioSummary(PortfolioSummary p) async {
    final db = await AppDatabase.instance.db;
    await db.insert('portfolio_summary_cache', {
      'id': 1,
      ...p.toDb(),
      'updated_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<PortfolioSummary?> getPortfolioSummary() async {
    final db = await AppDatabase.instance.db;
    final rows = await db.query('portfolio_summary_cache', where: 'id = 1');
    return rows.isEmpty ? null : PortfolioSummary.fromDb(rows.first);
  }

  Future<void> setRiskAssessment(RiskAssessment r) async {
    final db = await AppDatabase.instance.db;
    await db.insert('risk_assessment_cache', {
      'id': 1,
      ...r.toDb(),
      'updated_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<RiskAssessment?> getRiskAssessment() async {
    final db = await AppDatabase.instance.db;
    final rows = await db.query('risk_assessment_cache', where: 'id = 1');
    return rows.isEmpty ? null : RiskAssessment.fromDb(rows.first);
  }

  // ---------------- سجل عقل الآلي (Brain Log) ----------------
  Future<void> insertBrainEntries(List<BrainEntry> entries) async {
    final db = await AppDatabase.instance.db;
    final batch = db.batch();
    for (final e in entries) {
      batch.insert('brain_log', {
        'id': e.id,
        'ts': e.ts,
        'ts_full': e.tsFull,
        'level': e.level,
        'sym': e.sym,
        'msg': e.msg,
        'data_json': jsonEncode(e.data),
      });
    }
    await batch.commit(noResult: true);
    // احتفظ بآخر 500 فقط محلياً (نفس سقف BrainLog بالسيرفر)
    await db.execute('''
      DELETE FROM brain_log WHERE id NOT IN (
        SELECT id FROM brain_log ORDER BY id DESC LIMIT 500
      )
    ''');
  }

  Future<List<BrainEntry>> getBrainEntries({int limit = 200}) async {
    final db = await AppDatabase.instance.db;
    final rows =
        await db.query('brain_log', orderBy: 'id DESC', limit: limit);
    return rows.reversed
        .map((m) => BrainEntry(
              id: m['id'] as int,
              ts: m['ts'] as String? ?? '',
              tsFull: m['ts_full'] as String? ?? '',
              level: m['level'] as String? ?? '💭',
              sym: m['sym'] as String? ?? '',
              msg: m['msg'] as String? ?? '',
              data: (jsonDecode(m['data_json'] as String? ?? '{}') as Map)
                  .cast<String, dynamic>(),
            ))
        .toList();
  }

  Future<int> getMaxBrainId() async {
    final db = await AppDatabase.instance.db;
    final r = await db.rawQuery('SELECT MAX(id) as m FROM brain_log');
    return (r.first['m'] as int?) ?? 0;
  }

  // ---------------- محادثة الشات مع AI ----------------
  Future<int> insertChatMessage(ChatMessage m) async {
    final db = await AppDatabase.instance.db;
    return db.insert('chat_messages', m.toDb());
  }

  Future<void> markChatFailed(int id, bool failed) async {
    final db = await AppDatabase.instance.db;
    await db.update('chat_messages', {'failed': failed ? 1 : 0},
        where: 'id = ?', whereArgs: [id]);
  }

  Future<List<ChatMessage>> getChatMessages({int limit = 200}) async {
    final db = await AppDatabase.instance.db;
    final rows =
        await db.query('chat_messages', orderBy: 'id DESC', limit: limit);
    return rows.reversed.map(ChatMessage.fromDb).toList();
  }

  // ---------------- إعدادات key-value ----------------
  Future<void> setSetting(String k, String v) async {
    final db = await AppDatabase.instance.db;
    await db.insert('kv_settings', {'k': k, 'v': v});
  }

  Future<String?> getSetting(String k) async {
    final db = await AppDatabase.instance.db;
    final rows =
        await db.query('kv_settings', where: 'k = ?', whereArgs: [k]);
    return rows.isEmpty ? null : rows.first['v'] as String?;
  }
}
