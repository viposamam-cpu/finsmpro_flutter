import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

/// قاعدة بيانات محلية (SQLite) تُخزّن نسخة كاملة من بيانات الحساب على الجهاز:
/// المراكز المفتوحة، الصفقات المغلقة، قائمة المراقبة، كاش الأسعار، الإعدادات.
/// الهدف: التطبيق يفتح فوراً ببيانات آخر مزامنة حتى بدون إنترنت،
/// ثم يحدّث لحظياً بمجرد وصول tick جديد من السيرفر.
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'finsmpro_omega.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE positions (
            sym TEXT PRIMARY KEY,
            name TEXT,
            shares INTEGER,
            entry REAL,
            sl REAL,
            tp REAL,
            tf TEXT,
            opened TEXT,
            manual INTEGER DEFAULT 0
          )
        ''');

        await db.execute('''
          CREATE TABLE price_cache (
            sym TEXT PRIMARY KEY,
            price REAL,
            last_px REAL,
            prev_close REAL,
            close REAL,
            change REAL,
            change_pct REAL,
            is_live INTEGER,
            source TEXT,
            bar_time TEXT,
            stale INTEGER,
            updated_at INTEGER
          )
        ''');

        await db.execute('''
          CREATE TABLE closed_trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sym TEXT,
            name TEXT,
            shares INTEGER,
            entry REAL,
            exit_px REAL,
            pnl REAL,
            pnl_pct REAL,
            opened TEXT,
            closed TEXT,
            reason TEXT,
            synced INTEGER DEFAULT 1
          )
        ''');

        await db.execute('''
          CREATE TABLE watchlist (
            sym TEXT PRIMARY KEY,
            name TEXT,
            added_at INTEGER
          )
        ''');

        await db.execute('''
          CREATE TABLE brain_log (
            id INTEGER PRIMARY KEY,
            ts TEXT,
            ts_full TEXT,
            level TEXT,
            sym TEXT,
            msg TEXT,
            data_json TEXT
          )
        ''');

        // طابور العمليات التي تمت أوفلاين وتنتظر المزامنة مع السيرفر
        await db.execute('''
          CREATE TABLE pending_ops (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint TEXT,
            method TEXT,
            body_json TEXT,
            created_at INTEGER
          )
        ''');

        await db.execute('''
          CREATE TABLE kv_settings (
            k TEXT PRIMARY KEY,
            v TEXT
          )
        ''');

        // كاش شموع الشارت (sym+tf) — يسمح بفتح شاشة التحليل فوراً بدون
        // انتظار yfinance، ثم تحديثها بالخلفية
        await db.execute('''
          CREATE TABLE candles_cache (
            sym TEXT,
            tf TEXT,
            time INTEGER,
            open REAL,
            high REAL,
            low REAL,
            close REAL,
            volume INTEGER,
            PRIMARY KEY (sym, tf, time)
          )
        ''');

        // كاش آخر تحليل/إشارة لكل سهم
        await db.execute('''
          CREATE TABLE signal_cache (
            sym TEXT PRIMARY KEY,
            json TEXT,
            updated_at INTEGER
          )
        ''');

        // كاش نتيجة مسح قائمة المراقبة الكاملة — يسمح بفتح الشاشة فوراً
        await db.execute('''
          CREATE TABLE watchlist_scan_cache (
            sym TEXT PRIMARY KEY,
            name TEXT,
            price REAL,
            signal TEXT,
            color TEXT,
            sl REAL,
            tp REAL,
            updated_at INTEGER
          )
        ''');

        // كاش ملخص المحفظة وتقييم المخاطر (صف وحيد ثابت لكل جدول)
        await db.execute('''
          CREATE TABLE portfolio_summary_cache (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            cash REAL,
            equity REAL,
            positions_count INTEGER,
            ensemble_advice TEXT,
            updated_at INTEGER
          )
        ''');

        await db.execute('''
          CREATE TABLE risk_assessment_cache (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            risk_level TEXT,
            ensemble_assessment TEXT,
            updated_at INTEGER
          )
        ''');

        // سجل محادثة الشات مع AI — يبقى كاملاً بالجهاز حتى بدون إنترنت
        await db.execute('''
          CREATE TABLE chat_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT,
            is_user INTEGER,
            model TEXT,
            sym TEXT,
            ts INTEGER,
            failed INTEGER DEFAULT 0
          )
        ''');

        // سجل الصفقات المغلقة (تاريخي) — نفس أعمدة closed_trades بالسيرفر
        await db.execute('''
          CREATE TABLE closed_trades_cache (
            row_id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT,
            sym TEXT,
            name TEXT,
            buy_price REAL,
            sell_price REAL,
            shares INTEGER,
            pnl REAL,
            pnl_pct REAL,
            commission REAL,
            net_pnl REAL,
            duration TEXT,
            manual INTEGER
          )
        ''');
      },
    );
  }
}
