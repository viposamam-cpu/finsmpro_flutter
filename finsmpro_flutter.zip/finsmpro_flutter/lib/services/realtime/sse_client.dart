import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';

/// عميل SSE عام (Server-Sent Events) — يُستخدم للاتصال بـ /api/brain_stream
/// وأي مسار SSE آخر بالسيرفر. يعيد الاتصال تلقائياً عند الانقطاع
/// (نفس سلوك startBrainSSE في الواجهة الحالية: إعادة محاولة كل 5 ثوانٍ).
class SseClient {
  SseClient({required this.baseUrl});

  final String baseUrl;
  final Dio _dio = Dio();
  StreamSubscription? _sub;
  bool _stopped = false;

  final _controller = StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get stream => _controller.stream;

  void connect(String path) async {
    _stopped = false;
    await _connectOnce(path);
  }

  Future<void> _connectOnce(String path) async {
    if (_stopped) return;
    try {
      final res = await _dio.get<ResponseBody>(
        '$baseUrl$path',
        options: Options(
          responseType: ResponseType.stream,
          headers: {'Accept': 'text/event-stream'},
        ),
      );

      final stream = res.data!.stream
          .cast<List<int>>()
          .transform(utf8.decoder)
          .transform(const LineSplitter());

      _sub = stream.listen((line) {
        if (line.startsWith('data:')) {
          final payload = line.substring(5).trim();
          if (payload.isEmpty) return;
          try {
            _controller.add(jsonDecode(payload) as Map<String, dynamic>);
          } catch (_) {
            _controller.add({'raw': payload});
          }
        }
      }, onError: (_) => _reconnect(path), onDone: () => _reconnect(path));
    } catch (_) {
      _reconnect(path);
    }
  }

  void _reconnect(String path) {
    if (_stopped) return;
    Future.delayed(const Duration(seconds: 5), () => _connectOnce(path));
  }

  void dispose() {
    _stopped = true;
    _sub?.cancel();
    _controller.close();
  }
}
