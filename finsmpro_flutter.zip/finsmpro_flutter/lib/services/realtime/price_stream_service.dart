import 'dart:async';
import '../../models/price_snapshot.dart';
import '../api/finsmpro_api.dart';
import '../db/local_store.dart';
import 'sse_client.dart';

/// هذا هو الحل الفعلي لمشكلة "تأخر 20 ثانية":
/// 1) يحاول أولاً الاتصال بـ SSE للحصول على tick فوري بمجرد وصوله من
///    TradingView Webhook (يتطلب إضافة مسار /api/price_stream بالسيرفر —
///    راجع ملاحظة server_todo.md المرفقة).
/// 2) إن لم يتوفر SSE بعد، يستخدم fast-poll كل 3 ثوانٍ فقط للأسهم
///    الظاهرة فعلياً بالشاشة (وليس كل السوق) — بدل كاش 30 ثانية بالسيرفر.
/// في الحالتين، كل سعر يصل يُخزَّن فوراً بقاعدة البيانات المحلية
/// ويُبث لكل الشاشات المشتركة عبر [prices].
class PriceStreamService {
  PriceStreamService({required this.api, required this.baseUrl});

  final FinsmproApi api;
  final String baseUrl;

  SseClient? _sse;
  Timer? _pollTimer;
  final Set<String> _watchedSymbols = {};

  final _controller = StreamController<PriceSnapshot>.broadcast();
  Stream<PriceSnapshot> get prices => _controller.stream;

  void start() {
    _sse = SseClient(baseUrl: baseUrl)
      ..connect('/api/price_stream')
      ..stream.listen(_handleSseTick);
  }

  void _handleSseTick(Map<String, dynamic> j) {
    final sym = j['sym']?.toString();
    if (sym == null) return;
    final snap = PriceSnapshot.fromJson(sym, j);
    LocalStore.instance.upsertPrice(snap);
    _controller.add(snap);
  }

  /// يُستدعى عند فتح/إغلاق شاشة تعرض أسعار معيّنة
  void watchSymbols(List<String> symbols) {
    _watchedSymbols
      ..clear()
      ..addAll(symbols);
    _pollTimer?.cancel();
    if (_watchedSymbols.isEmpty) return;
    // fast-poll احتياطي فقط — يتوقف تلقائياً بمجرد استقبال أول tick عبر SSE
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollOnce());
    _pollOnce();
  }

  Future<void> _pollOnce() async {
    for (final sym in _watchedSymbols.toList()) {
      try {
        final res = await api.price(sym);
        final snap = PriceSnapshot.fromJson(sym, res);
        await LocalStore.instance.upsertPrice(snap);
        _controller.add(snap);
      } catch (_) {
        // فشل مؤقت — يُعاد المحاولة بالدورة القادمة، والشاشة تبقى تعرض
        // آخر سعر مخزّن محلياً بدل شاشة فارغة
      }
    }
  }

  void dispose() {
    _sse?.dispose();
    _pollTimer?.cancel();
    _controller.close();
  }
}
