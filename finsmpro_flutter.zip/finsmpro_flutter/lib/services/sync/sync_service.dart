import 'dart:async';
import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../api/finsmpro_api.dart';
import '../db/local_store.dart';

/// يراقب عودة الاتصال بالإنترنت ويُفرّغ طابور `pending_ops` تلقائياً —
/// أي عملية شراء/بيع/إعداد فشلت أثناء انقطاع النت تُنفَّذ فور عودته
/// بدون أي تدخل من المستخدم.
class SyncService {
  SyncService({required this.api});
  final FinsmproApi api;

  StreamSubscription<List<ConnectivityResult>>? _sub;
  bool _syncing = false;

  final _statusController = StreamController<SyncStatus>.broadcast();
  Stream<SyncStatus> get status => _statusController.stream;

  void start() {
    // حاول عند الإقلاع أيضاً — قد تكون هناك عمليات معلّقة من جلسة سابقة
    flushNow();
    _sub = Connectivity().onConnectivityChanged.listen((results) {
      final online = results.any((r) => r != ConnectivityResult.none);
      if (online) flushNow();
    });
  }

  Future<void> flushNow() async {
    if (_syncing) return;
    _syncing = true;
    try {
      final ops = await LocalStore.instance.getPendingOps();
      if (ops.isEmpty) return;
      _statusController.add(SyncStatus(pending: ops.length, syncing: true));

      var succeeded = 0;
      for (final op in ops) {
        try {
          final body =
              (jsonDecode(op['body_json'] as String? ?? '{}') as Map)
                  .cast<String, dynamic>();
          await api.replay(op['endpoint'] as String, body);
          await LocalStore.instance.clearPendingOp(op['id'] as int);
          succeeded++;
        } catch (_) {
          // لا يزال بدون اتصال أو فشل السيرفر — يبقى بالطابور للمحاولة القادمة
          break; // نتوقف بالترتيب حتى لا نُنفّذ عمليات لاحقة قبل سابقة فشلت
        }
      }
      _statusController.add(SyncStatus(pending: ops.length - succeeded, syncing: false));
    } finally {
      _syncing = false;
    }
  }

  void dispose() {
    _sub?.cancel();
    _statusController.close();
  }
}

class SyncStatus {
  final int pending;
  final bool syncing;
  const SyncStatus({required this.pending, required this.syncing});
}
