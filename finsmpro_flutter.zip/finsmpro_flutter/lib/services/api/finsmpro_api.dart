import 'dart:convert';
import 'package:dio/dio.dart';
import '../db/local_store.dart';

/// عميل API واحد يغطي كل endpoints السيرفر (أكثر من 40) عبر دالتين عامتين
/// [get] و [post] — بدل كتابة 40 دالة يدوياً بدون داعٍ. بالإضافة لدوال
/// مختصرة (typed) لأهم المسارات: portfolio, positions, price, buy, sell.
///
/// عدّل baseUrl حسب رابط السيرفر على Render.
class FinsmproApi {
  FinsmproApi({required this.baseUrl})
      : _dio = Dio(BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 8),
          receiveTimeout: const Duration(seconds: 15),
        ));

  final String baseUrl;
  final Dio _dio;

  // ---------------- عام: يغطي أي مسار موجود بالسيرفر ----------------
  Future<Map<String, dynamic>> get(String path,
      {Map<String, dynamic>? query}) async {
    final res = await _dio.get(path, queryParameters: query);
    return _asMap(res.data);
  }

  Future<Map<String, dynamic>> post(String path,
      {Map<String, dynamic>? body, bool queueOnFailure = true}) async {
    try {
      final res = await _dio.post(path, data: body);
      return _asMap(res.data);
    } on DioException {
      // لا يوجد اتصال أو فشل السيرفر → خزّن العملية محلياً لمزامنتها لاحقاً
      // (queueOnFailure=false تُستخدم أثناء إعادة تشغيل الطابور نفسه،
      // لتفادي إعادة تخزين نفس العملية إن فشلت مجدداً)
      if (queueOnFailure) {
        await LocalStore.instance.queuePendingOp(
          path,
          'POST',
          jsonEncode(body ?? {}),
        );
      }
      rethrow;
    }
  }

  /// يُستدعى من SyncService عند عودة الاتصال — يعيد تنفيذ عملية معلّقة
  /// بدون إعادة تخزينها بالطابور إذا فشلت مجدداً (SyncService يتولى إعادة المحاولة)
  Future<Map<String, dynamic>> replay(String path, Map<String, dynamic> body) =>
      post(path, body: body, queueOnFailure: false);

  Map<String, dynamic> _asMap(dynamic data) {
    if (data is Map<String, dynamic>) return data;
    return {'raw': data};
  }

  // ---------------- مختصرات للمسارات الأساسية ----------------
  Future<Map<String, dynamic>> portfolio() => get('/api/portfolio');
  Future<Map<String, dynamic>> positions() => get('/api/positions');
  Future<Map<String, dynamic>> marketStatus() => get('/api/market_status');

  /// فحص منفصل: سيرفر يعمل + قاعدة بيانات متصلة، كل واحدة لوحدها
  Future<Map<String, dynamic>> health() => get('/api/health');
  Future<Map<String, dynamic>> price(String sym) =>
      get('/api/price', query: {'sym': sym});
  Future<Map<String, dynamic>> analyze(String sym) =>
      get('/api/analyze', query: {'sym': sym});
  Future<Map<String, dynamic>> riskAnalysis() => get('/api/risk_analysis');
  Future<Map<String, dynamic>> portfolioAnalysis() => get('/api/portfolio_analysis');
  Future<Map<String, dynamic>> watchlistScan() => get('/api/watchlist_scan');
  Future<Map<String, dynamic>> closedTrades() => get('/api/closed_trades');
  Future<Map<String, dynamic>> newsFor(String sym) =>
      get('/api/news', query: {'sym': sym});
  Future<Map<String, dynamic>> brain() => get('/api/brain');
  Future<Map<String, dynamic>> chartData(String sym, {String tf = '1D'}) =>
      get('/api/chart_data', query: {'sym': sym, 'tf': tf});

  Future<Map<String, dynamic>> buy(
          {required String sym, required int shares, required double sl, required double tp}) =>
      post('/api/buy',
          body: {'sym': sym, 'shares': shares, 'sl': sl, 'tp': tp});

  Future<Map<String, dynamic>> sell(String sym) =>
      post('/api/sell', body: {'sym': sym});

  /// /api/chat فعلياً GET بمعاملات query (msg, model, sym) — ليس POST
  Future<Map<String, dynamic>> chat(String msg, {String model = 'openrouter-claude', String sym = '4030'}) =>
      get('/api/chat', query: {'msg': msg, 'model': model, 'sym': sym});

  // ---------------- الإعدادات ----------------
  Future<Map<String, dynamic>> settingsAll() => get('/api/settings_all');

  /// POST /api/settings بجسم {key, value} — تحديث إعداد واحد بالسيرفر
  Future<Map<String, dynamic>> setSetting(String key, String value) =>
      post('/api/settings', body: {'key': key, 'value': value});

  Future<Map<String, dynamic>> riskStatus() => get('/api/risk_status');
}
