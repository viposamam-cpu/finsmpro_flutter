import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/brain_entry.dart';
import '../services/db/local_store.dart';
import '../services/realtime/sse_client.dart';
import 'app_providers.dart';

/// اتصال SSE مستقل بقناة `/api/brain_stream` — منفصل تماماً عن
/// PriceStreamService حتى لا تتزاحم رسائل التفكير مع تحديثات الأسعار
/// (نفس الفصل الموجود بالسيرفر بين brain و price_stream).
final brainSseProvider = Provider<SseClient>((ref) {
  final url = ref.watch(serverUrlProvider);
  final client = SseClient(baseUrl: url)..connect('/api/brain_stream');
  ref.onDispose(client.dispose);
  return client;
});

final brainLogProvider =
    StateNotifierProvider<BrainLogNotifier, List<BrainEntry>>((ref) {
  final notifier = BrainLogNotifier(ref);
  ref.read(brainSseProvider).stream.listen(notifier.onLiveEntry);
  return notifier;
});

/// فلتر: عرض الكل أو فقط الأحداث المهمة (صفقات/تحذيرات)
final brainImportantOnlyProvider = StateProvider<bool>((_) => false);

class BrainLogNotifier extends StateNotifier<List<BrainEntry>> {
  BrainLogNotifier(this.ref) : super([]) {
    _loadLocalThenSync();
  }
  final Ref ref;

  Future<void> _loadLocalThenSync() async {
    final local = await LocalStore.instance.getBrainEntries();
    if (local.isNotEmpty) state = local;
    await _syncOnce();
  }

  Future<void> _syncOnce() async {
    try {
      final res = await ref.read(apiProvider).brain();
      final thoughts = (res['thoughts'] as List? ?? [])
          .map((e) => BrainEntry.fromJson(e as Map<String, dynamic>))
          .toList();
      if (thoughts.isNotEmpty) {
        await LocalStore.instance.insertBrainEntries(thoughts);
        state = thoughts;
      }
    } catch (_) {
      // بدون إنترنت: يبقى آخر سجل محلي كما هو
    }
  }

  /// يصل مباشرة من SSE فور حدوثه بالسيرفر — بدون أي تأخير polling
  void onLiveEntry(Map<String, dynamic> j) {
    final entry = BrainEntry.fromJson(j);
    LocalStore.instance.insertBrainEntries([entry]);
    state = [...state, entry];
    if (state.length > 500) {
      state = state.sublist(state.length - 500);
    }
  }
}
