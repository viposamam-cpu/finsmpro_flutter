import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/watch_item.dart';
import '../services/db/local_store.dart';
import 'app_providers.dart';

enum WatchFilter { all, buy, sell }

final watchFilterProvider = StateProvider<WatchFilter>((_) => WatchFilter.all);
final watchQueryProvider = StateProvider<String>((_) => '');

final watchlistProvider =
    StateNotifierProvider<WatchlistNotifier, _WatchState>((ref) {
  return WatchlistNotifier(ref);
});

class _WatchState {
  final List<WatchItem> items;
  final bool loading;
  final DateTime? lastSync;
  const _WatchState({this.items = const [], this.loading = true, this.lastSync});
  _WatchState copyWith({List<WatchItem>? items, bool? loading, DateTime? lastSync}) =>
      _WatchState(
        items: items ?? this.items,
        loading: loading ?? this.loading,
        lastSync: lastSync ?? this.lastSync,
      );
}

class WatchlistNotifier extends StateNotifier<_WatchState> {
  WatchlistNotifier(this.ref) : super(const _WatchState()) {
    _loadLocalThenSync();
  }
  final Ref ref;

  Future<void> _loadLocalThenSync() async {
    final local = await LocalStore.instance.getWatchScan();
    if (local.isNotEmpty) {
      state = state.copyWith(items: local, loading: false);
    }
    await refresh();
  }

  Future<void> refresh() async {
    state = state.copyWith(loading: true);
    try {
      final res = await ref.read(apiProvider).watchlistScan();
      final list = (res['raw'] is List ? res['raw'] : (res['results'] ?? []))
              as List? ??
          [];
      final items =
          list.map((e) => WatchItem.fromJson(e as Map<String, dynamic>)).toList();
      if (items.isNotEmpty) {
        await LocalStore.instance.upsertWatchScan(items);
      }
      state = state.copyWith(
        items: items.isEmpty ? state.items : items,
        loading: false,
        lastSync: DateTime.now(),
      );
    } catch (_) {
      state = state.copyWith(loading: false);
    }
  }
}

/// القائمة بعد تطبيق الفلتر والبحث — تُستهلك مباشرة من الشاشة
final filteredWatchlistProvider = Provider<List<WatchItem>>((ref) {
  final items = ref.watch(watchlistProvider).items;
  final filter = ref.watch(watchFilterProvider);
  final query = ref.watch(watchQueryProvider).trim();

  Iterable<WatchItem> out = items;
  if (filter == WatchFilter.buy) out = out.where((e) => e.isBuy);
  if (filter == WatchFilter.sell) out = out.where((e) => e.isSell);
  if (query.isNotEmpty) {
    out = out.where((e) =>
        e.sym.contains(query) || e.name.contains(query));
  }
  return out.toList();
});
