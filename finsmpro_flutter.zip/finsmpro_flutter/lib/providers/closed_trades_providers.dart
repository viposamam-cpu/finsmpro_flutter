import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/closed_trade.dart';
import '../services/db/local_store.dart';
import 'app_providers.dart';

final closedTradesProvider =
    StateNotifierProvider<ClosedTradesNotifier, List<ClosedTrade>>((ref) {
  return ClosedTradesNotifier(ref);
});

class ClosedTradesNotifier extends StateNotifier<List<ClosedTrade>> {
  ClosedTradesNotifier(this.ref) : super([]) {
    _loadLocalThenSync();
  }
  final Ref ref;

  Future<void> _loadLocalThenSync() async {
    final local = await LocalStore.instance.getClosedTrades();
    if (local.isNotEmpty) state = local;
    await refresh();
  }

  Future<void> refresh() async {
    try {
      final res = await ref.read(apiProvider).closedTrades(limit: 100);
      final list = (res['raw'] as List? ?? [])
          .map((e) => ClosedTrade.fromJson(e as Map<String, dynamic>))
          .toList();
      if (list.isNotEmpty) {
        await LocalStore.instance.replaceClosedTrades(list);
        state = list;
      }
      ref.read(connectionStatusProvider.notifier).reportSuccess();
    } catch (e) {
      ref.read(connectionStatusProvider.notifier).reportError(e);
    }
  }
}

/// إجمالي الأرباح/الخسائر الصافية لكل الصفقات المغلقة — لعرضه بأعلى الشاشة
final closedTradesSummaryProvider = Provider<(double totalNet, int wins, int losses)>((ref) {
  final trades = ref.watch(closedTradesProvider);
  final total = trades.fold<double>(0, (sum, t) => sum + t.netPnl);
  final wins = trades.where((t) => t.isWin).length;
  return (total, wins, trades.length - wins);
});
