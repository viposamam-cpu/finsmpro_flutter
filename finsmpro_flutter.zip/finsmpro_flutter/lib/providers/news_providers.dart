import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/closed_trade.dart';
import 'app_providers.dart';

/// أخبار سهم واحد — تُجلب عند فتح شاشة التحليل، بدون تخزين محلي
/// (الأخبار تتغيّر باستمرار ولا فائدة من كاشها طويلاً)
final newsProvider = FutureProvider.family<List<NewsItem>, String>((ref, sym) async {
  final res = await ref.read(apiProvider).newsFor(sym);
  final list = (res['raw'] as List? ?? []);
  return list.map((e) => NewsItem.fromJson(e as Map<String, dynamic>)).toList();
});
