import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'app_providers.dart';

const _kServerUrlKey = 'server_base_url';
const _secureStorage = FlutterSecureStorage();

class AppSettings {
  final String tradingStyle; // 🟡 منضبط / 🔴 عدواني ...
  final bool eliteMode;
  final bool circuitOpen; // للعرض فقط — يُتحكم به من محرك المخاطر بالسيرفر
  final bool marketHoursSim;
  final bool loading;
  final bool saving;

  const AppSettings({
    this.tradingStyle = '🟡 منضبط',
    this.eliteMode = false,
    this.circuitOpen = false,
    this.marketHoursSim = true,
    this.loading = true,
    this.saving = false,
  });

  AppSettings copyWith({
    String? tradingStyle,
    bool? eliteMode,
    bool? circuitOpen,
    bool? marketHoursSim,
    bool? loading,
    bool? saving,
  }) =>
      AppSettings(
        tradingStyle: tradingStyle ?? this.tradingStyle,
        eliteMode: eliteMode ?? this.eliteMode,
        circuitOpen: circuitOpen ?? this.circuitOpen,
        marketHoursSim: marketHoursSim ?? this.marketHoursSim,
        loading: loading ?? this.loading,
        saving: saving ?? this.saving,
      );
}

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, AppSettings>((ref) {
  return SettingsNotifier(ref);
});

class SettingsNotifier extends StateNotifier<AppSettings> {
  SettingsNotifier(this.ref) : super(const AppSettings()) {
    _loadServerUrl();
    refresh();
  }
  final Ref ref;

  Future<void> _loadServerUrl() async {
    final saved = await _secureStorage.read(key: _kServerUrlKey);
    if (saved != null && saved.trim().isNotEmpty) {
      ref.read(serverUrlProvider.notifier).state = saved.trim();
    }
  }

  /// يحفظ الرابط بتخزين آمن ويبدّله فوراً — كل الخدمات (API/SSE) تعيد
  /// الاتصال تلقائياً لأنها تراقب serverUrlProvider
  Future<void> setServerUrl(String url) async {
    final clean = url.trim();
    if (clean.isEmpty) return;
    await _secureStorage.write(key: _kServerUrlKey, value: clean);
    ref.read(serverUrlProvider.notifier).state = clean;
    await refresh();
  }

  Future<void> refresh() async {
    state = state.copyWith(loading: true);
    try {
      final res = await ref.read(apiProvider).riskStatus();
      state = state.copyWith(
        tradingStyle: res['style'] ?? state.tradingStyle,
        eliteMode: res['elite_mode'] == true,
        circuitOpen: res['circuit_open'] == true,
        marketHoursSim: res['market_hours'] == true,
        loading: false,
      );
    } catch (_) {
      state = state.copyWith(loading: false);
    }
  }

  Future<void> setTradingStyle(String style) async {
    state = state.copyWith(tradingStyle: style, saving: true);
    try {
      await ref.read(apiProvider).setSetting('trading_style', style);
    } catch (_) {
      // يبقى القيمة المحلية كما هي؛ ستتزامن بالمحاولة القادمة
    }
    state = state.copyWith(saving: false);
  }

  Future<void> setEliteMode(bool v) async {
    state = state.copyWith(eliteMode: v, saving: true);
    try {
      await ref.read(apiProvider).setSetting('elite_mode', v ? '1' : '0');
    } catch (_) {}
    state = state.copyWith(saving: false);
  }
}
