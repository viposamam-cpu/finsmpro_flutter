import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/portfolio_summary.dart';
import '../services/db/local_store.dart';
import 'app_providers.dart';

class RiskScreenState {
  final PortfolioSummary? portfolio;
  final RiskAssessment? risk;
  final bool loading;
  const RiskScreenState({this.portfolio, this.risk, this.loading = true});

  RiskScreenState copyWith(
          {PortfolioSummary? portfolio, RiskAssessment? risk, bool? loading}) =>
      RiskScreenState(
        portfolio: portfolio ?? this.portfolio,
        risk: risk ?? this.risk,
        loading: loading ?? this.loading,
      );
}

final riskScreenProvider =
    StateNotifierProvider<RiskScreenNotifier, RiskScreenState>((ref) {
  return RiskScreenNotifier(ref);
});

class RiskScreenNotifier extends StateNotifier<RiskScreenState> {
  RiskScreenNotifier(this.ref) : super(const RiskScreenState()) {
    _loadLocalThenSync();
  }
  final Ref ref;

  Future<void> _loadLocalThenSync() async {
    final port = await LocalStore.instance.getPortfolioSummary();
    final risk = await LocalStore.instance.getRiskAssessment();
    if (port != null || risk != null) {
      state = state.copyWith(portfolio: port, risk: risk, loading: false);
    }
    await refresh();
  }

  Future<void> refresh() async {
    final api = ref.read(apiProvider);
    state = state.copyWith(loading: true);
    try {
      final portRes = await api.portfolioAnalysis();
      final port = PortfolioSummary.fromJson(portRes);
      await LocalStore.instance.setPortfolioSummary(port);

      final riskRes = await api.riskAnalysis();
      final risk = RiskAssessment.fromJson(riskRes);
      await LocalStore.instance.setRiskAssessment(risk);

      state = state.copyWith(portfolio: port, risk: risk, loading: false);
    } catch (_) {
      state = state.copyWith(loading: false);
    }
  }
}
