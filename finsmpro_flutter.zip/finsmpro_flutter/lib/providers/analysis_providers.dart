import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/analysis.dart';
import '../services/db/local_store.dart';
import 'app_providers.dart';

/// حالة شاشة التحليل الفني لسهم واحد: شموع + إشارة، كل واحدة تُحمَّل
/// من التخزين المحلي فوراً ثم تُزامَن مع السيرفر بالخلفية.
class AnalysisState {
  final List<Candle> candles;
  final List<ChartMarker> markers;
  final StockSignal? signal;
  final bool loading;

  const AnalysisState({
    this.candles = const [],
    this.markers = const [],
    this.signal,
    this.loading = true,
  });

  AnalysisState copyWith({
    List<Candle>? candles,
    List<ChartMarker>? markers,
    StockSignal? signal,
    bool? loading,
  }) =>
      AnalysisState(
        candles: candles ?? this.candles,
        markers: markers ?? this.markers,
        signal: signal ?? this.signal,
        loading: loading ?? this.loading,
      );
}

final analysisProvider = StateNotifierProvider.family<AnalysisNotifier,
    AnalysisState, String>((ref, sym) {
  return AnalysisNotifier(ref, sym);
});

class AnalysisNotifier extends StateNotifier<AnalysisState> {
  AnalysisNotifier(this.ref, this.sym) : super(const AnalysisState()) {
    _loadLocalThenSync();
  }

  final Ref ref;
  final String sym;
  static const _tf = '1d';

  Future<void> _loadLocalThenSync() async {
    final localCandles = await LocalStore.instance.getCandles(sym, _tf);
    final localSignal = await LocalStore.instance.getSignal(sym);
    if (localCandles.isNotEmpty || localSignal != null) {
      state = state.copyWith(
        candles: localCandles,
        signal: localSignal,
        loading: false,
      );
    }
    await refresh();
  }

  Future<void> refresh() async {
    final api = ref.read(apiProvider);
    try {
      final chartRes = await api.chartData(sym, tf: _tf);
      final candles = (chartRes['candles'] as List? ?? [])
          .map((e) => Candle.fromJson(e as Map<String, dynamic>))
          .toList();
      final markers = (chartRes['markers'] as List? ?? [])
          .map((e) => ChartMarker.fromJson(e as Map<String, dynamic>))
          .toList();
      if (candles.isNotEmpty) {
        await LocalStore.instance.upsertCandles(sym, _tf, candles);
      }

      final sigRes = await api.analyze(sym);
      final signal = StockSignal.fromJson(sigRes);
      await LocalStore.instance.setSignal(sym, sigRes);

      state = state.copyWith(
        candles: candles.isEmpty ? state.candles : candles,
        markers: markers,
        signal: signal,
        loading: false,
      );
    } catch (_) {
      // بدون إنترنت: تبقى آخر نسخة محلية معروضة، فقط أوقف مؤشر التحميل
      state = state.copyWith(loading: false);
    }
  }
}
