import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/chat_message.dart';
import '../services/db/local_store.dart';
import 'app_providers.dart';

/// النموذج المختار حالياً (يظهر باختيار قابل للتبديل بالشاشة)
final chatModelProvider = StateProvider<String>((_) => 'openrouter-claude');

/// السهم المرتبط بسياق السؤال الحالي — اختياري، يفيد بأسئلة مثل
/// "ما رأيك بهذا السهم؟" بدون كتابة الرمز بكل مرة
final chatSymContextProvider = StateProvider<String>((_) => '4030');

final chatProvider =
    StateNotifierProvider<ChatNotifier, List<ChatMessage>>((ref) {
  return ChatNotifier(ref);
});

class ChatNotifier extends StateNotifier<List<ChatMessage>> {
  ChatNotifier(this.ref) : super([]) {
    _loadLocal();
  }
  final Ref ref;

  Future<void> _loadLocal() async {
    state = await LocalStore.instance.getChatMessages();
  }

  Future<void> send(String text) async {
    if (text.trim().isEmpty) return;
    final model = ref.read(chatModelProvider);
    final sym = ref.read(chatSymContextProvider);
    final now = DateTime.now().millisecondsSinceEpoch;

    final userMsg = ChatMessage(text: text, isUser: true, model: model, sym: sym, ts: now);
    final userId = await LocalStore.instance.insertChatMessage(userMsg);
    state = [...state, ChatMessage(id: userId, text: text, isUser: true, model: model, sym: sym, ts: now)];

    // رسالة انتظار مؤقتة أثناء وصول الرد
    final pendingId = DateTime.now().microsecondsSinceEpoch;
    state = [
      ...state,
      ChatMessage(id: pendingId, text: '...', isUser: false, model: model, sym: sym, ts: now + 1),
    ];

    try {
      final res = await ref.read(apiProvider).chat(text, model: model, sym: sym);
      final reply = res['reply']?.toString() ?? 'لم يصل رد.';
      final replyTs = DateTime.now().millisecondsSinceEpoch;
      final replyMsg = ChatMessage(text: reply, isUser: false, model: model, sym: sym, ts: replyTs);
      final replyId = await LocalStore.instance.insertChatMessage(replyMsg);

      state = [
        for (final m in state)
          if (m.id == pendingId)
            ChatMessage(id: replyId, text: reply, isUser: false, model: model, sym: sym, ts: replyTs)
          else
            m,
      ];
    } catch (_) {
      state = [
        for (final m in state)
          if (m.id == pendingId)
            ChatMessage(
                id: pendingId,
                text: 'تعذّر الوصول للسيرفر — تحقق من الاتصال.',
                isUser: false,
                model: model,
                sym: sym,
                ts: now + 1,
                failed: true)
          else
            m,
      ];
    }
  }
}
