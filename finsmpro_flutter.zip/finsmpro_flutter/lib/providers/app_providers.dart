import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/position.dart';
import '../models/price_snapshot.dart';
import '../services/api/finsmpro_api.dart';
import '../services/db/local_store.dart';
import '../services/realtime/price_stream_service.dart';
import '../services/sync/sync_service.dart';

/// 🔧 الرابط الافتراضي — يمكن تغييره من شاشة الإعدادات بدون إعادة بناء
/// التطبيق (محفوظ بتخزين آمن، راجع main.dart لآلية التحميل عند الإقلاع)
const String kServerBaseUrl = 'https://your-finsmpro-server.onrender.com';

/// رابط السيرفر الفعلي المستخدم — قابل للتبديل من شاشة الإعدادات،
/// وكل الخدمات (API, price stream, brain SSE) تراقبه وتعيد الاتصال تلقائياً
final serverUrlProvider = StateProvider<String>((_) => kServerBaseUrl);

final apiProvider = Provider<FinsmproApi>((ref) {
  final url = ref.watch(serverUrlProvider);
  return FinsmproApi(baseUrl: url);
});

final priceStreamProvider = Provider<PriceStreamService>((ref) {
  final url = ref.watch(serverUrlProvider);
  final svc = PriceStreamService(api: ref.read(apiProvider), baseUrl: url);
  svc.start();
  ref.onDispose(svc.dispose);
  return svc;
});

/// خدمة مزامنة العمليات المعلّقة أوفلاين — تبدأ تلقائياً مع أول استخدام
final syncServiceProvider = Provider<SyncService>((ref) {
  final svc = SyncService(api: ref.read(apiProvider));
  svc.start();
  ref.onDispose(svc.dispose);
  return svc;
});

/// عدد العمليات المعلّقة حالياً — لعرضه بشريط صغير بالواجهة
final pendingOpsCountProvider = StateProvider<int>((_) => 0);

/// المراكز المفتوحة: يقرأ من التخزين المحلي فوراً (شاشة لا تُفتح فارغة)
/// ثم يزامن مع السيرفر بالخلفية ويحدّث القائمة.
final positionsProvider =
    StateNotifierProvider<PositionsNotifier, List<Position>>((ref) {
  return PositionsNotifier(ref.read(apiProvider));
});

class PositionsNotifier extends StateNotifier<List<Position>> {
  PositionsNotifier(this._api) : super([]) {
    _loadLocalThenSync();
  }
  final FinsmproApi _api;

  Future<void> _loadLocalThenSync() async {
    state = await LocalStore.instance.getPositions();
    await refresh();
  }

  Future<void> refresh() async {
    try {
      final res = await _api.positions();
      final list = (res['positions'] as List? ?? [])
          .map((e) => Position.fromJson(e as Map<String, dynamic>))
          .toList();
      if (list.isNotEmpty) {
        await LocalStore.instance.upsertPositions(list);
        state = list;
      }
    } catch (_) {
      // بدون إنترنت: تبقى آخر نسخة محلية معروضة كما هي
    }
  }
}

/// أسعار حية لكل الرموز المعروضة حالياً
final livePricesProvider =
    StateNotifierProvider<LivePricesNotifier, Map<String, PriceSnapshot>>(
        (ref) {
  final notifier = LivePricesNotifier();
  ref.read(priceStreamProvider).prices.listen(notifier.onTick);
  return notifier;
});

class LivePricesNotifier extends StateNotifier<Map<String, PriceSnapshot>> {
  LivePricesNotifier() : super({}) {
    LocalStore.instance.getAllPrices().then((v) => state = v);
  }

  void onTick(PriceSnapshot p) {
    state = {...state, p.sym: p};
  }
}
