import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import '../models/position.dart';
import '../models/price_snapshot.dart';
import '../services/api/finsmpro_api.dart';
import '../services/db/local_store.dart';
import '../services/realtime/price_stream_service.dart';
import '../services/sync/sync_service.dart';

/// 🔧 الرابط الافتراضي — يمكن تغييره من شاشة الإعدادات بدون إعادة بناء
/// التطبيق (محفوظ بتخزين آمن، راجع main.dart لآلية التحميل عند الإقلاع)
const String kServerBaseUrl = 'https://your-finsmpro-server.onrender.com';

/// رابط السيرفر الفعلي المستخدم — قابل للتبديل من شاشة الإعدادات،
/// وكل الخدمات (API, price stream, brain SSE) تراقبه وتعيد الاتصال تلقائياً
final serverUrlProvider = StateProvider<String>((_) => kServerBaseUrl);

final apiProvider = Provider<FinsmproApi>((ref) {
  final url = ref.watch(serverUrlProvider);
  return FinsmproApi(baseUrl: url);
});

final priceStreamProvider = Provider<PriceStreamService>((ref) {
  final url = ref.watch(serverUrlProvider);
  final svc = PriceStreamService(api: ref.read(apiProvider), baseUrl: url);
  svc.start();
  ref.onDispose(svc.dispose);
  return svc;
});

/// خدمة مزامنة العمليات المعلّقة أوفلاين — تبدأ تلقائياً مع أول استخدام
final syncServiceProvider = Provider<SyncService>((ref) {
  final svc = SyncService(api: ref.read(apiProvider));
  svc.start();
  ref.onDispose(svc.dispose);
  return svc;
});

/// عدد العمليات المعلّقة حالياً — لعرضه بشريط صغير بالواجهة
final pendingOpsCountProvider = StateProvider<int>((_) => 0);

/// ═══════════════════════════════════════════════════════════════
/// حالة الاتصال بالسيرفر — يكشف فوراً "تعذّر الاتصال" بدل شاشة فارغة
/// صامتة تبدو كأنها "لا توجد بيانات". أي فشل بأي provider يُبلّغ هنا.
/// ═══════════════════════════════════════════════════════════════
class ConnectionStatus {
  final bool connected; // السيرفر يستجيب
  final bool databaseOk; // قاعدة البيانات متصلة (فقط ذو معنى لو connected=true)
  final String? errorMessage;
  final DateTime? lastCheck;
  const ConnectionStatus(
      {this.connected = true, this.databaseOk = true, this.errorMessage, this.lastCheck});
}

final connectionStatusProvider =
    StateNotifierProvider<ConnectionStatusNotifier, ConnectionStatus>((ref) {
  final notifier = ConnectionStatusNotifier(ref);
  notifier.checkNow();
  return notifier;
});

class ConnectionStatusNotifier extends StateNotifier<ConnectionStatus> {
  ConnectionStatusNotifier(this.ref) : super(const ConnectionStatus(connected: true));
  final Ref ref;

  Future<void> checkNow() async {
    try {
      final res = await ref.read(apiProvider).health();
      final dbOk = res['database'] == 'ok';
      state = ConnectionStatus(
        connected: true,
        databaseOk: dbOk,
        errorMessage: dbOk ? null : 'قاعدة البيانات: ${res['database_error'] ?? 'خطأ غير معروف'}',
        lastCheck: DateTime.now(),
      );
    } catch (e) {
      state = ConnectionStatus(
        connected: false,
        databaseOk: false,
        errorMessage: describeDioError(e, ref.read(serverUrlProvider)),
        lastCheck: DateTime.now(),
      );
    }
  }

  /// تُستدعى من أي provider آخر عند فشل طلب — تُبقي البانر ظاهراً بنفس السبب
  void reportError(Object e) {
    state = ConnectionStatus(
      connected: false,
      databaseOk: false,
      errorMessage: describeDioError(e, ref.read(serverUrlProvider)),
      lastCheck: DateTime.now(),
    );
  }

  void reportSuccess() {
    if (!state.connected || !state.databaseOk) {
      state = ConnectionStatus(connected: true, databaseOk: true, lastCheck: DateTime.now());
    }
  }
}

/// يحوّل خطأ Dio لرسالة عربية واضحة تشرح *لماذا* فشل الاتصال تحديداً —
/// بدل رسالة عامة "حدث خطأ" لا تفيد بالتشخيص
String describeDioError(Object e, String url) {
  if (e is DioException) {
    switch (e.type) {
      case DioExceptionType.connectionError:
        return 'تعذّر الوصول لـ $url — تأكد أن الرابط صحيح بشاشة الإعدادات '
            '(الرابط الحالي قد يكون لا يزال الافتراضي غير المُعدَّل).';
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
        return 'انتهت مهلة الاتصال بـ $url خلال 15 ثانية.';
      case DioExceptionType.badResponse:
        return 'السيرفر رد بخطأ ${e.response?.statusCode} على $url';
      default:
        return 'تعذّر الاتصال بـ $url (${e.type.name})';
    }
  }
  return 'خطأ غير متوقع أثناء الاتصال بـ $url';
}

/// المراكز المفتوحة: يقرأ من التخزين المحلي فوراً (شاشة لا تُفتح فارغة)
/// ثم يزامن مع السيرفر بالخلفية ويحدّث القائمة.
final positionsProvider =
    StateNotifierProvider<PositionsNotifier, List<Position>>((ref) {
  return PositionsNotifier(ref);
});

class PositionsNotifier extends StateNotifier<List<Position>> {
  PositionsNotifier(this.ref) : super([]) {
    _loadLocalThenSync();
  }
  final Ref ref;

  Future<void> _loadLocalThenSync() async {
    state = await LocalStore.instance.getPositions();
    await refresh();
  }

  Future<void> refresh() async {
    try {
      final res = await ref.read(apiProvider).positions();
      final list = (res['positions'] as List? ?? [])
          .map((e) => Position.fromJson(e as Map<String, dynamic>))
          .toList();
      await LocalStore.instance.upsertPositions(list);
      state = list; // حتى لو فارغة فعلياً — هذا فرق مهم عن "فشل الاتصال"
      ref.read(connectionStatusProvider.notifier).reportSuccess();
    } catch (e) {
      // لا نُخفي الخطأ بعد الآن — نُبلّغ حالة الاتصال العامة، وتبقى
      // آخر نسخة محلية معروضة كما هي (تجربة مستخدم أفضل من شاشة فارغة صامتة)
      ref.read(connectionStatusProvider.notifier).reportError(e);
    }
  }
}

/// أسعار حية لكل الرموز المعروضة حالياً
final livePricesProvider =
    StateNotifierProvider<LivePricesNotifier, Map<String, PriceSnapshot>>(
        (ref) {
  final notifier = LivePricesNotifier();
  ref.read(priceStreamProvider).prices.listen(notifier.onTick);
  return notifier;
});

class LivePricesNotifier extends StateNotifier<Map<String, PriceSnapshot>> {
  LivePricesNotifier() : super({}) {
    LocalStore.instance.getAllPrices().then((v) => state = v);
  }

  void onTick(PriceSnapshot p) {
    state = {...state, p.sym: p};
  }
}
