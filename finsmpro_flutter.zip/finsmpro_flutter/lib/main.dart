import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'providers/app_providers.dart';
import 'screens/root_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // اقرأ رابط السيرفر المحفوظ (إن وُجد) قبل بناء أي provider، حتى لا
  // يبدأ التطبيق اتصاله الأول بالرابط الافتراضي الخاطئ
  const storage = FlutterSecureStorage();
  final savedUrl = await storage.read(key: 'server_base_url');

  runApp(ProviderScope(
    overrides: [
      if (savedUrl != null && savedUrl.trim().isNotEmpty)
        serverUrlProvider.overrideWith((ref) => savedUrl.trim()),
    ],
    child: const FinsmproApp(),
  ));
}

class FinsmproApp extends StatelessWidget {
  const FinsmproApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FinSMPro Omega',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF0B5D3B),
        useMaterial3: true,
        fontFamily: 'Cairo',
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
      home: const RootShell(),
    );
  }
}
